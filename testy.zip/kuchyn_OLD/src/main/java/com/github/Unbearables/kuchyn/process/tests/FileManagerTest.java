package com.github.Unbearables.kuchyn.process.tests;

import org.junit.Test;
import static org.junit.Assert.*;

import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Menu;

import junit.framework.TestCase;
import org.junit.Before;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.gson.*;
import com.google.gson.stream.JsonReader;

public class FileManagerTest {
	
	FileManager fileManager = new FileManager();
	String date1 = "26.05.2018";
	//private Menu menu;

	
	@Before
	public void testInitialize() throws Exception {
		fileManager.initialize();
		System.out.println("FileManager byl inicializován");
	};
	
	@Test
	public void testcreateMainTxt() throws Exception {
		fileManager.createMainTxt("testcompanyName", "testcompanyType", "testcompanyICO");
		
		assertNotNull(fileManager.getKitchenName());
		
		System.out.println(fileManager.getKitchenName());
		System.out.println(fileManager.getKitchenType());
		System.out.println(fileManager.getKitchenIco());
	}
	
	@Test
	public void testGetMenu() {
		assertNotNull(fileManager.getMenu(date1));
		System.out.println("Menu na " + date1 + " není prázdné");
	}

}
