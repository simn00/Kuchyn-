package com.github.Unbearables.kuchyn.ui;

import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.main.Start;
import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FirstStartController
{
	@FXML private AnchorPane rootPane3;
	@FXML private TextField name;
	@FXML private TextField type;
	
	private FileManager fileManager = Start.fileManager;
	

	public void createAndContinue() throws IOException
	{
		fileManager.createMainTxt(name.getText(), type.getText());
		toMainWindow();
	}	
	
	public void toMainWindow() throws IOException 
	{		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Kuchyn_MainWindow.fxml"));		
		
		Parent root = (Parent) loader.load();
		MainWindowController controller = loader.getController();
		
		Scene menu_overview_scene = new Scene(root);
		Stage app_stage = (Stage) (rootPane3.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();		
	}	
	
}