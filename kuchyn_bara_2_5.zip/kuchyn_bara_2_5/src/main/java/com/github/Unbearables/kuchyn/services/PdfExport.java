package com.github.Unbearables.kuchyn.services;

//import com.itextpdf.text.*;
//import com.itextpdf.text.pdf.*;



import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfWriter;
import javafx.scene.paint.Color;


import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public final class PdfExport {
    public static void createPdf(String filename) throws FileNotFoundException, DocumentException {
        // step 1
        Document document = new Document(PageSize.A4);
        // step 2
        PdfWriter.getInstance(document, new FileOutputStream(filename));
        // step 3
        document.open();
        // step 4
        document.add(new Header("H1","Denní menu"));

        Font headers =  FontFactory.getFont(FontFactory.TIMES_BOLD,"Cp1250", 16, Font.BOLD,BaseColor.BLACK);
        Font meals = FontFactory.getFont(FontFactory.TIMES_BOLD, "Cp1250",12, Font.NORMAL,BaseColor.BLACK);
        Font basic = FontFactory.getFont(FontFactory.TIMES, "Cp1250",10, Font.NORMAL,BaseColor.BLACK);


        document.add(new Paragraph("Denní menu", headers));
        document.add(new Paragraph(" "));
        document.add(new Paragraph("Vítejte u nás, blah blah, nějaký žvásty o restauraci"));
        document.add(new Paragraph("Jídlo 1:", meals));
        document.add(new Paragraph("Svíčková", basic));
        document.add(new Paragraph("Jídlo 2", meals));
        document.add(new Paragraph("Kdnedle", basic));
        document.add(new Paragraph("Jídlo 3:", meals));
        document.add(new Paragraph("Blááto", basic));
        document.add(new Paragraph("Polévka:", meals));
        document.add(new Paragraph("Bamboračka", basic));
        document.add(new Paragraph("Dezert:", meals));
        document.add(new Paragraph("Buchty ", basic));




        document.add(new Paragraph("Hello World!"));
        // step 5
        document.close();
    }

//    Document document = new Document();
//    PdfWriter pdfw = new PdfWriter("aaa.pdf");
//PdfWriter.getInstance(document, new FileOutputStream("iTextHelloWorld.pdf"));
//document
//document.open();
//
//    Font font = FontFactory.getFont(FontFactory.COURIER, 16, BaseColor.BLACK);
//    Chunk chunk = new Chunk("Hello World", font);
//
//document.add(chunk);
//document.close();

}
