package com.github.Unbearables.kuchyn.process;

import java.util.List;

public class Menu 
{
	private String datum;
	private List<String> recepty;
	
	public Menu(String datum, List<String> recepty) 
	{
		this.datum = datum;
		this.recepty = recepty;
	}
	
	public String getDatum() 
	{
		return datum;
	}
	
	public List<String> getRecepty() 
	{
		return recepty;
	}
}
