package com.github.Unbearables.kuchyn.process;

public class Sklad {

}
