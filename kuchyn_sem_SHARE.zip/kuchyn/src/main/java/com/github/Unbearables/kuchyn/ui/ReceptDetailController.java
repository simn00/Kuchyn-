package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Recept;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ReceptDetailController
{
	@FXML private AnchorPane rootPane6;
	@FXML private Label receptNazev;
	@FXML private Label receptChod;
	@FXML private ListView<String> seznamSurovin;
	
	private FileManager fileManager = Start.fileManager;
	
	private Recept recept;
	
	private List<String> surovinyRecept; 
	
	public void initialize() 
	{
		recept = fileManager.getClickedRecept();
		receptNazev.setText(recept.getNazev());
		receptChod.setText(recept.getChod());
		
		surovinyRecept = new ArrayList<String>();
		
		List<String> test = recept.getSuroviny();
		
		for( int i = 0 ; i < test.size() ; i++ ) 
		{
			String[] blo = test.get(i).split("_");
			surovinyRecept.add(blo[0] + " " + blo[1] + " " + blo[2]);
		}
		
		seznamSurovin.getItems().addAll(surovinyRecept);
	}
	
	public void takeData() 
	{
		
	}
	
	public void zpetNaRecepty() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Recepty.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane6.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
}