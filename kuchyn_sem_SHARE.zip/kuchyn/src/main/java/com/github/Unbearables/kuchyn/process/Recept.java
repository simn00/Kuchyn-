package com.github.Unbearables.kuchyn.process;

import java.util.List;

public class Recept {

	private String nazev;
	private String chod;
	
	//private String suroviny;
	private List<String> suroviny;
	
	public Recept(String nazev, String chod, List<String> suroviny) 
	{
		this.nazev = nazev;
		this.chod = chod;
		this.suroviny = suroviny;
	}
	
	public String getNazev() 
	{
		return nazev;
	}
	
	public String getChod() 
	{
		return chod;
	}
	
	public String toString() 
	{
		return nazev;
	}
	
	public List<String> getSuroviny()
	{
		return suroviny;
	}
}
