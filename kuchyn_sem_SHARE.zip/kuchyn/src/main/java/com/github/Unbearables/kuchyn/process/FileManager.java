package com.github.Unbearables.kuchyn.process;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.gson.*;
import com.google.gson.stream.JsonReader;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class FileManager {

	public File mainTxt;
	private File receptyJSON;
	private File menuJSON;
	List<String> mainTxtInfo = new ArrayList<String>();
	
	public boolean firstStart = true;
	private PrintWriter writer;
	private String kitchenName;
	private String kitchenType;
	
	private JSONArray receptyArray;

	private ObservableList<Recept> recepty;
	private Recept clickedRecept;
	
	private ObservableList<Recept> bitchass;
	
	private Menu menuTest;
	
	public void initialize() throws FileNotFoundException, JSONException 
	{
		mainTxt = new File("test.txt");
		receptyJSON = new File("recepty.json");
		menuJSON = new File("menu.json");
		
		receptyArray = new JSONArray();
		getJSONToObsList();
		
		if(!mainTxt.exists() || mainTxt.length() == 0) 
		{
			System.out.println("file doesn't exist or is empty, creating one");
		}
		else
		{
			System.out.println("file exists");
			
			//read existing file
			try 
			{
				BufferedReader reader = new BufferedReader(new FileReader(mainTxt));
				String line = reader.readLine();
				
				while (line != null) 
				{
					mainTxtInfo.add(line);
					line = reader.readLine();
				}
				reader.close();
			}
			catch (IOException e) {}
			
			//set variables
			kitchenName = mainTxtInfo.get(0);
			kitchenType = mainTxtInfo.get(1);
			
			firstStart = false;
		}
	}
	
	//take parameters
	public void createMainTxt(String companyName, String companyType) 
	{
		try 
		{
			writer = new PrintWriter("test.txt", "UTF-8");
			kitchenName = companyName;
			kitchenType = companyType;
			writer.println(companyName);
			writer.println(companyType);
			writer.close();
		}
		catch (IOException ex) {}		
	}
		
	public void writeRecept(JSONObject obj) 
	{
		try (PrintWriter writer = new PrintWriter(new FileOutputStream(receptyJSON,false)))
		{
			receptyArray.put(obj);
			System.out.println(receptyArray);
			writer.write(receptyArray.toString());
		} 
		catch(IOException e) {}
	}
		
	public ObservableList<Recept> getJSONToObsList() throws FileNotFoundException, JSONException
	{
		//if json isnt empty
		if(receptyJSON.length() > 3)
		{
			recepty = FXCollections.observableArrayList();

			Gson gson = new Gson();
			JsonReader reader = new JsonReader(new FileReader(receptyJSON));
			Recept[] test = gson.fromJson(reader, Recept[].class);
			
			if(receptyArray.length() == 0)
			{
				for(int j=0; j < test.length; j++)
				{
					JSONObject obj = new JSONObject();
					
					obj.put("nazev", test[j].getNazev());
					obj.put("chod", test[j].getChod());
					obj.put("suroviny", test[j].getSuroviny());
					
					receptyArray.put(obj);
				}
			}
			
			for(int i=0; i < test.length; i++)
			{
				recepty.add(test[i]);
			}
			
			return recepty;
		}
		return null;
	}
	
	public ObservableList<Recept> getJSONToMenu(String datum) throws FileNotFoundException, JSONException
	{
		menuTest = null;
		bitchass = FXCollections.observableArrayList();
		//if json isnt empty
		if(menuJSON.length() > 3)
		{
			Gson gson = new Gson();
			JsonReader reader = new JsonReader(new FileReader(menuJSON));
			Menu[] test = gson.fromJson(reader, Menu[].class);
			
			for(int i=0; i < test.length; i++)
			{
				if(datum.equals(test[i].getDatum())) 
				{
					menuTest = test[i];
					break;
				}
			}
			
			if(menuTest != null)
			{
				for(int k=0; k < menuTest.getRecepty().size(); k++) 
				{
					String hovno = menuTest.getRecepty().get(k);
					
					for(int n=0; n < recepty.size(); n++) 
					{
						if(hovno.equals(recepty.get(n).getNazev())) 
						{
							bitchass.add(recepty.get(n));
							break;
						}
					}
				}
			}
			
			return bitchass;
		}
		else
		{
			System.out.println("menu neexsituje");
		}
		return null;
	}
	
	public ObservableList<Surovina> getSurkyZReceptu() 
	{
		ObservableList<Surovina> tesst = FXCollections.observableArrayList();
		
		for(int i=0 ; i < bitchass.size() ; i++) 
		{
			List<String> fuuuck = bitchass.get(i).getSuroviny();
			
			for(int j=0 ; j < fuuuck.size() ; j++) 
			{
				boolean dontAdd = false;
				String[] raf = fuuuck.get(j).split("_");
				
				Surovina sur = new Surovina(raf[0], raf[2]);
				sur.setMnozstvi(Float.parseFloat(raf[1]));
				
				for(int k=0 ; k < tesst.size() ; k++) 
				{	
					if(sur.getNazev().equals(tesst.get(k).getNazev()))
					{
						tesst.get(k).addMnozstvi(Float.parseFloat(raf[1]));
						dontAdd = true;
					}
				}
				
				if(!dontAdd) 
				{
					tesst.add(sur);
				}
			}
		}
		return tesst;
	}
	
	public void odstranReceptJSON(Recept recept) throws JSONException 
	{
		recepty.remove(recept);
		
		for(int i=0; i < receptyArray.length(); i++) 
		{	
			if(receptyArray.getJSONObject(i).get("nazev").equals(recept.getNazev())) 
			{
				System.out.println(recept + " destroyed");
				receptyArray.remove(i);
				break;
			}
		}
		
		try (PrintWriter writer = new PrintWriter(new FileOutputStream(receptyJSON,false)))
		{
			writer.write(receptyArray.toString());
		} 
		catch(IOException e) {}
	}
	
	public ObservableList<Recept> getRecepty()
	{
		return recepty;
	}
	
	public File getFile() 
	{
		return receptyJSON;
	}
	
	public void setClickedRecept(Recept recept) 
	{
		clickedRecept = recept;
	}
	
	public Recept getClickedRecept() 
	{
		return clickedRecept;
	}
	
	public boolean getFirstStart() 
	{
		return firstStart;
	}
	
	public String getKitchenName() 
	{
		return kitchenName;	
	}
	
	public String getKitchenType() 
	{
		return kitchenType;	
	}
}