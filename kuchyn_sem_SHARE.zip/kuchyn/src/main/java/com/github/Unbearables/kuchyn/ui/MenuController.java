package com.github.Unbearables.kuchyn.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;

import org.json.JSONException;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Menu;
import com.github.Unbearables.kuchyn.process.Recept;
import com.github.Unbearables.kuchyn.process.Surovina;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;



public class MenuController
{
	@FXML private AnchorPane rootPane2;
	@FXML private Label todayDate;
	@FXML private DatePicker menuDatePicker;
	@FXML private ListView<Recept> menuRecepty;
	@FXML private TableView<Surovina> menuSuroviny;
	@FXML private TableColumn<Recept, String> nazevSuroviny;
    @FXML private TableColumn<Recept, String> mnozstviSuroviny;
    @FXML private TableColumn<Recept, String> jednotkaSuroviny;
	
	private FileManager fileManager = Start.fileManager;
	private String today;
	private LocalDate localDate;
	
	private DateTimeFormatter dtf;
	

	public void initialize() throws FileNotFoundException, JSONException 
	{
		LocalDateTime dateTime = LocalDateTime.now();
		String fullDate = dateTime.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
		
		dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		today = dateTime.format(dtf);
		localDate = LocalDate.parse(today, dtf);
		
		todayDate.setText(fullDate);
		menuDatePicker.setValue(localDate);
				
		menuRecepty.setItems(fileManager.getJSONToMenu(today));
		menuSuroviny.setItems(fileManager.getSurkyZReceptu());
		
		//suroviny table
		nazevSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("nazev"));
		mnozstviSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("mnozstvi"));
		jednotkaSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("jednotka"));
	}
	
	
	public void backToTheKitchen() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane2.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
	public void nextDay() 
	{
		menuDatePicker.setValue(menuDatePicker.getValue().plusDays(1));
	} 
	
	public void prevDay() 
	{
		menuDatePicker.setValue(menuDatePicker.getValue().minusDays(1));
	}
	
	public void updateListView() throws FileNotFoundException, JSONException 
	{
		ObservableList<Recept> test = fileManager.getJSONToMenu(menuDatePicker.getValue().format(dtf).toString());
		
		menuRecepty.setItems(test);
		menuSuroviny.setItems(fileManager.getSurkyZReceptu());
	}
}