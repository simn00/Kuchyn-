package com.github.Unbearables.kuchyn.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.function.Predicate;

import org.json.JSONException;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Recept;

import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class ReceptyController
{
	@FXML private AnchorPane rootPane4;
	@FXML private TableView<Recept> receptyTable;
	@FXML private TableColumn<Recept, String> nazevReceptu;
    @FXML private TableColumn<Recept, String> chodReceptu;
    @FXML private TextField searchField;
    @FXML private ContextMenu tableContextMenu;
	
	private FileManager fileManager = Start.fileManager;
	private FilteredList<Recept> filterRecepty;
	
	//private FilteredList<Recept> filterRecepty = new FilteredList<Recept> (fileManager.getRecepty(), e->true);
	
	
	public void initialize() throws FileNotFoundException, JSONException
	{
		nazevReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("nazev"));
		chodReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("chod"));
		
		receptyTable.setItems(fileManager.getJSONToObsList());
		filterRecepty = new FilteredList<Recept> (fileManager.getRecepty(), e->true);
	}
	
	public void backToTheKitchen() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane4.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
	public void goToCreateRecept() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_NewRecept.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane4.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
	@SuppressWarnings("unchecked")
	public void search(KeyEvent event) 
	{
		searchField.textProperty().addListener((observable, oldValue, newValue) -> {
			
			filterRecepty.setPredicate((Predicate<? super Recept>) (Recept recept)->{
				
				if(newValue.isEmpty() || newValue == null) 
				{
					return true;
				}
				else if(recept.getNazev().toLowerCase().contains(newValue.toLowerCase()))
				{
					return true;
				}
				
				return false;
			});
		});
		
		@SuppressWarnings("rawtypes")
		SortedList sort = new SortedList(filterRecepty);
		sort.comparatorProperty().bind(receptyTable.comparatorProperty());
		receptyTable.setItems(sort);
	}
	
	public void odstranRecept() 
	{	
		Recept recept = receptyTable.getSelectionModel().getSelectedItem();
		
		if(recept != null) 
		{
			//fileManager.odstranReceptZCsv(recept);
			receptyTable.getSelectionModel().clearSelection();
		}
	}
	
	public void goToRecept() throws IOException
	{
		Recept receptToGo = receptyTable.getSelectionModel().getSelectedItem();
		
		if(receptToGo != null) 
		{
			fileManager.setClickedRecept(receptToGo);
			
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_ReceptDetail.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (rootPane4.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
	}
}