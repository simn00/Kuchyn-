package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;

import org.json.JSONException;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Sklad;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewSkladController
{
	@FXML private AnchorPane skladNovyPane;
	@FXML private TextField nazevSurovina;
	@FXML private TextField mnozstviSuroviny;
	@FXML private Label errorNazevSurovina;
	@FXML private Label errorUdaje;
	
	private FileManager fileManager = Start.fileManager;
	private ObservableList<Sklad> sklad;
	
	public void initialize() 
	{
		errorNazevSurovina.setText(null);
		errorUdaje.setText(null);
		
		sklad = fileManager.getSklad();
	}
	
	public void pridejSurovinu() throws IOException, JSONException
	{
		if(nazevSurovina.getText() != null && nazevSurovina.getText().matches("\\p{L}*")  && mnozstviSuroviny.getText() != null) 
		{
			fileManager.writeSklad(nazevSurovina.getText(), Float.parseFloat(mnozstviSuroviny.getText()));
			backToSklad();
		}
		else 
		{
			errorUdaje.setText("Musíš vyplnit potřebné údaje");
		}
	}
	
	public boolean checkForDuplicateSurovina()
	{
		if (sklad != null)
		{
			for(int i = 0; i < sklad.size(); i++) 
			{
				//tady zjisti jestli surovina existuje
				if (sklad.get(i).getNazev().toLowerCase().equals(nazevSurovina.getText().toLowerCase().trim().replaceAll(" +", " ")))
				{	
					return true;
				}				
			}
		}
		return false;
	}
	
	public void backToSklad() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladNovyPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
}