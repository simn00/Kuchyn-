package com.github.Unbearables.kuchyn.process;

import java.util.List;

public class Recept {

	private String nazev;
	private String chod;
	private float cena;
	private float doba;
	private List<String> suroviny;
	private String poznamka;
	
	public Recept(String nazev, String chod, float cena, float doba, List<String> suroviny) 
	{
		this.nazev = nazev;
		this.chod = chod;
		this.cena = cena;
		this.doba = doba;
		this.suroviny = suroviny;
	}
	
	public String getNazev() 
	{
		return nazev;
	}
	
	public String getChod() 
	{
		return chod;
	}
	
	public float getCena() 
	{
		return cena;
	}
	
	public float getDoba() 
	{
		return doba;
	}
	
	public List<String> getSuroviny()
	{
		return suroviny;
	}
	
	public String getPoznamka() 
	{
		return poznamka;
	}
	
	public void setPoznamka(String pozn) 
	{
		poznamka = pozn;
	}
	
	public String toString() 
	{
		return nazev;
	}
}
