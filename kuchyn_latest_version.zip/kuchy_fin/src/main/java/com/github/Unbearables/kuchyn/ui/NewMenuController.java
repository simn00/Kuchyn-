package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewMenuController
{
	@FXML AnchorPane newMenuPane;
	@FXML DatePicker datumMenu;
	@FXML Slider pocetReceptu;
	@FXML TextField textRecept1;
	@FXML TextField textRecept2;
	@FXML TextField textRecept3;
	@FXML TextField textRecept4;
	@FXML TextField textRecept5;

	@FXML TextField pocetReceptu1;
	@FXML TextField pocetReceptu2;
	@FXML TextField pocetReceptu3;
	@FXML TextField pocetReceptu4;
	@FXML TextField pocetReceptu5;
	
	
	public void initialize() 
	{
		textRecept4.setDisable(true);
		pocetReceptu4.setDisable(true);
		textRecept5.setDisable(true);
		pocetReceptu5.setDisable(true);
	}
	
	public void backToMenu() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Menu.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (newMenuPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void updatePocetReceptu() 
	{
		textRecept1.setDisable(true);
		pocetReceptu1.setDisable(true);
		textRecept2.setDisable(true);
		pocetReceptu2.setDisable(true);
		textRecept3.setDisable(true);
		pocetReceptu3.setDisable(true);
		textRecept4.setDisable(true);
		pocetReceptu4.setDisable(true);
		textRecept5.setDisable(true);
		pocetReceptu5.setDisable(true);
		
		for( int i=1 ; i <= pocetReceptu.getValue() ; i++) 
		{
			TextField tf1 = (TextField) newMenuPane.getScene().lookup("#textRecept" + i);
			TextField tf2 = (TextField) newMenuPane.getScene().lookup("#pocetReceptu" + i);
			
			if(tf1.isDisabled()) 
			{
				tf1.setDisable(false);
				tf2.setDisable(false);
			}
		}
	}
}