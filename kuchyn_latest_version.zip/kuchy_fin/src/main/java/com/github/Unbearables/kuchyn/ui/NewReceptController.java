package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Recept;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewReceptController
{
	@FXML private AnchorPane rootPane5;
	@FXML private TextField nazevRecept;
	@FXML private ChoiceBox<String> chodRecept;
	@FXML private TextArea poznamkaRecept;	
	@FXML private Label poznamkaCounter;
	@FXML private Label errorLabel;	
	@FXML private Label errorNazevRecept;
	@FXML private TextField cenaRecept;
	@FXML private TextField dobaRecept;
	
	//suroviny stuff
	@FXML private TextField nazevSuroviny;
	@FXML private TextField mnozSuroviny;
	@FXML private ChoiceBox<String> jednMnozSuroviny;
	@FXML private ListView<String> seznamSurovin;
	
	private List<String> surovinyRecept;
	private FileManager fileManager = Start.fileManager;
	
	private static final int DELKA_POZN = 150;
	
	private JSONObject recept;
	private JSONArray surList;
	
	public void initialize() 
	{
		errorLabel.setText(null);
		errorNazevRecept.setText(null);
		poznamkaCounter.setText(DELKA_POZN + "/" + DELKA_POZN);
		chodRecept.getItems().addAll("snídaně","předkrm","polévka","hlavní jídlo","jídlo k pivu","dezert","nápoj");	
		jednMnozSuroviny.getItems().addAll("g","ml","l","ks");
		
		surovinyRecept = new ArrayList<String>();
		surList = new JSONArray();
		recept = new JSONObject();
	}
	
	public void vytvorRecept() throws IOException, JSONException
	{
		checkForDuplicateRecept();
		checkCenaDoba();
		
		if(nazevRecept.getText() != null && chodRecept.getSelectionModel().getSelectedItem() != null && !surovinyRecept.isEmpty() && !checkForDuplicateRecept() && !checkCenaDoba()) 
		{	
			recept.put("nazev", nazevRecept.getText());
			recept.put("chod", chodRecept.getSelectionModel().getSelectedItem());
			recept.put("cena", Float.parseFloat(cenaRecept.getText()));
			recept.put("doba", Float.parseFloat(dobaRecept.getText()));
			recept.put("poznamka", poznamkaRecept.getText());
			recept.put("suroviny", surList);
			
			fileManager.writeRecept(recept);
			fileManager.getRecepty();
			backToRecepty();
		}
		else 
		{
			errorLabel.setText("Musíš vyplnit potřebné údaje");
		}
	}
	
	public boolean checkCenaDoba() 
	{
		if(cenaRecept.getText() != null && dobaRecept.getText() != null)
		{
			if(cenaRecept.getText().matches("(^[1-9]\\d?\\d?\\d?,\\d\\d?)|(^[1-9]\\d?\\d?\\d?)") && dobaRecept.getText().matches("^[1-9]\\d*")) 
			{
				return false;
			}			
		}
		return true;
	}
	
	public void poznamkaCountWords() 
	{
		poznamkaCounter.setText(DELKA_POZN - poznamkaRecept.getLength() + "/" + DELKA_POZN);
		
		if(poznamkaRecept.getLength() > DELKA_POZN) 
		{
			String s = poznamkaRecept.getText().substring(0, DELKA_POZN);
			poznamkaRecept.setText(s);
			poznamkaRecept.positionCaret(DELKA_POZN);
			poznamkaCounter.setText(0 + "/" + DELKA_POZN);
		}
	}
	
	public boolean checkForDuplicateRecept()
	{
		ObservableList<Recept> recepty = fileManager.getRecepty();
		
		if(recepty != null) 
		{
			for(int i = 0; i < recepty.size(); i++) 
			{
				if (recepty.get(i).getNazev().toLowerCase().equals(nazevRecept.getText().toLowerCase().trim().replaceAll(" +", " ")))
				{
					errorNazevRecept.setText("Název receptu již existuje");
					return true;
				}
			}
		}
		
		errorNazevRecept.setText(null);
		return false;
	}
	
	public void backToRecepty() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Recepty.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane5.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
	public void pridejSurovinu() throws JSONException 
	{
		if(mnozSuroviny.getText().matches("(^[1-9]\\d?\\d?,\\d\\d?)|(^[1-9]\\d?\\d?)")) 
		{
			if(nazevSuroviny.getText() != null && mnozSuroviny.getText() != null && jednMnozSuroviny.getSelectionModel().getSelectedItem() != null) 
			{
				String viewSurovina = (nazevSuroviny.getText() + " " + mnozSuroviny.getText() + " " +  jednMnozSuroviny.getSelectionModel().getSelectedItem()).trim().replaceAll(" +", " ");
				String finalSurovina = (nazevSuroviny.getText() + "_" + mnozSuroviny.getText() + "_" + jednMnozSuroviny.getSelectionModel().getSelectedItem()).trim().replaceAll(" +", " ");
				JSONObject sur = new JSONObject();
				sur.put(nazevSuroviny.getText().trim().replaceAll(" +", " "), Integer.parseInt(mnozSuroviny.getText().trim().replaceAll(" +", " ")));
				
				boolean surDupl = false;
				
				for (int i=0 ; i < surovinyRecept.size(); i++) 
				{
					String[] recSur = surovinyRecept.get(i).split("_");
					
					if(recSur[0].toLowerCase().trim().replaceAll(" +", " ").equals(nazevSuroviny.getText().toLowerCase().trim().replaceAll(" +", " "))) 
					{
						surDupl = true;
					}
				}
				
				if(!surDupl)
				{
					surovinyRecept.add(finalSurovina);
					seznamSurovin.getItems().add(viewSurovina);
					surList.put(finalSurovina);
					
					//resets input fields
					nazevSuroviny.setText(null);
					mnozSuroviny.setText(null);
					jednMnozSuroviny.valueProperty().set(null);
					errorLabel.setText(null);
				}
				else 
				{
					errorLabel.setText("surovina " + viewSurovina + " je již přidána.");
				}
			}
		}
		else 
		{
			errorLabel.setText("Špatně zadané množství suroviny: " + mnozSuroviny.getText());
			mnozSuroviny.setText(null);
		}
	}
	
	public void odeberSurovinu() throws JSONException 
	{
		String odebiranaSurovina = seznamSurovin.getSelectionModel().getSelectedItem();
		surovinyRecept.remove(najdiVSurovinach(odebiranaSurovina));
		seznamSurovin.getItems().remove(odebiranaSurovina);
		
		for(int n = 0; n < surList.length(); n++)
		{
		    String surString = surList.get(n).toString();
		    
		    if(surString.equals(najdiVSurovinach(odebiranaSurovina))) 
		    {
		    	surList.remove(n);
		    	break;
		    }
		}
	}
	
	public String najdiVSurovinach(String surovina) 
	{
		String substring = surovina.substring(surovina.lastIndexOf(" ", surovina.lastIndexOf(" ") - 1));
		String jmenoSur = surovina.replace(substring, "");
		String finSubstring = substring.replaceAll(" +", "_");
		String finalString = jmenoSur + finSubstring;
		return finalString;
	}
}