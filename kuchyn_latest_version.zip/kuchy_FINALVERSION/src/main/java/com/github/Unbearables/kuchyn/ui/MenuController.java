package com.github.Unbearables.kuchyn.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

import org.json.JSONException;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Recept;
import com.github.Unbearables.kuchyn.process.Sklad;
import com.github.Unbearables.kuchyn.process.Surovina;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MenuController
{
	@FXML private AnchorPane rootPane2;
	@FXML private Label todayDate;
	@FXML private DatePicker menuDatePicker;
	@FXML private TableView<Recept> menuTable;
	@FXML private TableView<Surovina> menuSuroviny;
	@FXML private TableColumn<Recept, String> nazevSuroviny;
    @FXML private TableColumn<Recept, String> mnozstviSuroviny;
    @FXML private TableColumn<Recept, String> jednotkaSuroviny;
    
    @FXML private TableColumn<Recept, String> nazevReceptu;
    @FXML private TableColumn<Recept, String> recPocPorci;
    @FXML private Button actionBtn;
    @FXML private Button odstranitBtn;
	
	private FileManager fileManager = Start.fileManager;
	private LocalDate localDate;
	private DateTimeFormatter dtf;
	
	private ObservableList<Sklad> sklad;

	public void initialize() throws FileNotFoundException, JSONException 
	{
		LocalDateTime dateTime = LocalDateTime.now();
		String fullDate = dateTime.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
		String today = fileManager.getToday();
		
		dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		localDate = LocalDate.parse(today, dtf);
		
		sklad = fileManager.getSklad();
		
		todayDate.setText(fullDate);
		menuDatePicker.setValue(localDate);
				
		//menuRecepty.setItems(fileManager.getJSONToMenu(today));
		menuTable.setItems(fileManager.getJSONToMenu(today));
		menuSuroviny.setItems(fileManager.getSurkyZReceptu());
		
		//menuTable
		nazevReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("nazev"));
		recPocPorci.setCellValueFactory(new PropertyValueFactory<Recept, String>("pocetPorci"));
		
		//suroviny table
		nazevSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("nazev"));
		mnozstviSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("mnozstvi"));
		jednotkaSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("jednotka"));
		
		updateListView();
	}
	
	
	public void backToTheKitchen() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane2.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
	public void changeOrCreate() throws IOException
	{
		fileManager.setClickedMenuDatum(menuDatePicker.getValue().format(dtf).toString());
		
		if(menuTable.getItems().isEmpty()) 
		{
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Menu_New.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (rootPane2.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
		else 
		{
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Menu_Change.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (rootPane2.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
			//call afterInit();
		}
	}
	
	public void nextDay() 
	{
		menuDatePicker.setValue(menuDatePicker.getValue().plusDays(1));
	} 
	
	public void prevDay() 
	{
		menuDatePicker.setValue(menuDatePicker.getValue().minusDays(1));
	}
	
	public void updateBtns() 
	{
		if(menuTable.getItems().isEmpty()) 
		{
			actionBtn.setText("Nové menu");
			odstranitBtn.setVisible(false);
		}
		else 
		{
			actionBtn.setText("Změnit menu");
			odstranitBtn.setVisible(true);
		}
	}
	
	//on date picker change
	public void updateListView() throws FileNotFoundException, JSONException 
	{
		ObservableList<Recept> test = fileManager.getJSONToMenu(menuDatePicker.getValue().format(dtf).toString());
		
		menuTable.setItems(test);
		menuSuroviny.setItems(fileManager.getSurkyZReceptu());
		updateBtns();
		
		//zjištění dostatku surovin
		menuSuroviny.setRowFactory(surovina -> new TableRow<Surovina>() {
		    @Override
		    public void updateItem(Surovina sur, boolean empty) 
		    {
		        super.updateItem(sur, empty);
		        
		        if (sur == null) 
		        {		        	
		            setStyle("");
		            setTooltip(null);
		        } 
		        else 
		        {	
					for( int j=0; j < sklad.size(); j++ ) 
					{	
						Tooltip tooltip = new Tooltip();
						tooltip.setStyle("-fx-font-size: 12px;");
						
						if(sur.getNazev().equals(sklad.get(j).getNazev())) 
						{
							if(sur.getMnozstvi() > sklad.get(j).getMnozstvi()) 
							{
								//suroviny není dostatek
								setStyle("-fx-background-color: tomato;");
								tooltip.setText("Chybí " + (sur.getMnozstvi() - sklad.get(j).getMnozstvi()));
							    setTooltip(tooltip);
							}
							else 
							{
								//surovina je na skladu
								setStyle("");
								tooltip.setText("Na skladu: " + sklad.get(j).getMnozstvi());
							    setTooltip(tooltip);
							}
							
							break;
						}
						
						//surovina není na skladu vůbec
						setStyle("-fx-background-color: red;");
						tooltip.setText("Surovina na skladu není!");
					    setTooltip(tooltip);
					}
		        }
		    }
		});
	}
	
	public void odstranitMenu() throws FileNotFoundException, JSONException 
	{
		String dayToDel = menuDatePicker.getValue().format(dtf).toString();
		//popup
		Alert alert = new Alert(AlertType.WARNING, "Opravdu chcete menu odstranit?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
		alert.setTitle("Odstranění menu");
		alert.setHeaderText("Odstranit menu na den " + dayToDel);
		alert.showAndWait();
		
		if(alert.getResult() == ButtonType.YES) 
		{
			fileManager.odstranMenu(dayToDel);
			updateListView();
		}
	}
	
	public void goToRecept() throws IOException
	{
		Recept receptToGo = menuTable.getSelectionModel().getSelectedItem();
		
		if(receptToGo != null) 
		{
			fileManager.setClickedRecept(receptToGo);
			
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_ReceptDetail.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (rootPane2.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
	}
}