package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Sklad;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class NewSkladController
{
	@FXML private AnchorPane skladNovyPane;
	@FXML private TextField nazevSurovina;
	@FXML private TextField mnozstviSuroviny;
	@FXML private Label errorSur;
	
	private FileManager fileManager = Start.fileManager;
	private ObservableList<Sklad> sklad;
	@FXML private ChoiceBox<String> jednMnozSur;
	@FXML private ListView<String> seznamSur;
	
	private List<String> surovinySklad;
	private JSONArray surovinaList;
	
	public void initialize() 
	{
		errorSur.setText(null);
		jednMnozSur.getItems().addAll("g","ml","ks");
		
		surovinySklad = new ArrayList<String>();
		surovinaList = new JSONArray();
		sklad = fileManager.getSklad();
	}
	
	public void pridejNakup() throws IOException, JSONException
	{
		for( int i=0; i < surovinySklad.size(); i++) 
		{
			String[] pomocna = surovinySklad.get(i).split("_");
			fileManager.writeSklad(pomocna[0], Float.parseFloat(pomocna[1]), pomocna[2], false);
		}
		backToSklad();
	}

	public void pridejSur() throws JSONException, IOException 
	{
		if(mnozstviSuroviny.getText().matches("^-?(0\\.\\d*[1-9]\\d*|[1-9]\\d*(\\.\\d+)?)$"))
		{
			if(nazevSurovina.getText().matches("^\\p{L}[\\p{L} ]*\\p{L}$"))
			{
				if(nazevSurovina.getText() != null && mnozstviSuroviny.getText() != null && jednMnozSur.getSelectionModel().getSelectedItem() != null) 
				{
					String viewSurovina = (nazevSurovina.getText() + " " + mnozstviSuroviny.getText() + " " +  jednMnozSur.getSelectionModel().getSelectedItem()).trim().replaceAll(" +", " ");
					String finalSurovina = (nazevSurovina.getText() + "_" + mnozstviSuroviny.getText() + "_" + jednMnozSur.getSelectionModel().getSelectedItem()).trim().replaceAll(" +", " ");
					JSONObject sur = new JSONObject();
					sur.put(nazevSurovina.getText().trim().replaceAll(" +", " "), Float.parseFloat(mnozstviSuroviny.getText().trim().replaceAll(" +", " ")));
					
					boolean surDupl = false;
					
					for (int i=0 ; i < surovinySklad.size(); i++) 
					{
						String[] skSur = surovinySklad.get(i).split("_");
						
						if(skSur[0].toLowerCase().trim().replaceAll(" +", " ").equals(nazevSurovina.getText().toLowerCase().trim().replaceAll(" +", " "))) 
						{
							surDupl = true;
						}
					}
					
					if(!surDupl)
					{
						surovinySklad.add(finalSurovina);
						seznamSur.getItems().add(viewSurovina);
						surovinaList.put(finalSurovina);
						
						//resets input fields
						nazevSurovina.setText(null);
						mnozstviSuroviny.setText(null);
						jednMnozSur.valueProperty().set(null);
						errorSur.setText(null);
						System.out.println(surovinySklad);
					}
					else 
					{
						errorSur.setText("surovina " + viewSurovina + " je již přidána.");
					}
				}
				else
				{
					errorSur.setText("Musíš vyplnit všechny údaje.");
				}
			}
			else
			{
				errorSur.setText("Špatně zadaný název suroviny.");
			}
		}
		else 
		{
			errorSur.setText("Špatně zadané množství suroviny: " + mnozstviSuroviny.getText());
			mnozstviSuroviny.setText(null);
		}
	}
	
	
	public boolean checkForDuplicateSurovina()
	{
		if(sklad != null)
		{
			for(int i = 0; i < sklad.size(); i++) 
			{
				//tady zjisti jestli surovina existuje
				if (sklad.get(i).getNazev().toLowerCase().equals(nazevSurovina.getText().toLowerCase().trim().replaceAll(" +", " ")))
				{	
					return true;
				}				
			}
		}
		return false;
	}
	
	public void odeberSur() throws JSONException 
	{
		String odebiranaSurovina = seznamSur.getSelectionModel().getSelectedItem();
		surovinySklad.remove(najdiVSurovinach(odebiranaSurovina));
		seznamSur.getItems().remove(odebiranaSurovina);
		
		for(int n = 0; n < surovinaList.length(); n++)
		{
		    String surString = surovinaList.get(n).toString();
		    
		    if(surString.equals(najdiVSurovinach(odebiranaSurovina))) 
		    {
		    	surovinaList.remove(n);
		    	break;
		    }
		}
	}
	
	public String najdiVSurovinach(String surovina) 
	{
		String substring = surovina.substring(surovina.lastIndexOf(" ", surovina.lastIndexOf(" ") - 1));
		String jmenoSur = surovina.replace(substring, "");
		String finSubstring = substring.replaceAll(" +", "_");
		String finalString = jmenoSur + finSubstring;
		return finalString;
	}
	
	public void backToSklad() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladNovyPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
}