package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;

import org.json.JSONException;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Sklad;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SkladDetailController
{
	@FXML private AnchorPane skladDetailPane;
	@FXML private Label nazev;
	@FXML private Label mnozstvi;
	@FXML private Label jednotka;
	@FXML private Label errorMnozstvi;
	@FXML private TextField odecetMnozstvi;
	
	private FileManager fileManager = Start.fileManager;
	
	private Sklad sklad;
	
	
	public void initialize() 
	{
		sklad = fileManager.getClickedSklad();
		nazev.setText(sklad.getNazev());
		mnozstvi.setText(sklad.getMnozstvi() + "");
		jednotka.setText(sklad.getJednotka());
	
		errorMnozstvi.setText(null);
	}
	
	public void takeData() 
	{
		
	}
	
	public void zmenaMnozstvi() throws IOException, JSONException
	{
		System.out.println(odecetMnozstvi.getText());
		if(odecetMnozstvi.getText().matches("^-?(0\\.\\d*[1-9]\\d*|[1-9]\\d*(\\.\\d+)?)$"))
			{
					if(odecetMnozstvi.getText() != null)
				{
					float konecna = Float.parseFloat(mnozstvi.getText()) - Float.parseFloat(odecetMnozstvi.getText());
					if(konecna >= 0)
						{
							fileManager.writeSklad(nazev.getText(), Float.parseFloat(odecetMnozstvi.getText()), jednotka.getText(), true);
							zpetNaSklad();
						}
						else
						{
							errorMnozstvi.setText("Nemůžeš odečíst toto množství.");
						}	
					}
				else 
				{
					errorMnozstvi.setText("Musíš zadat správné číslo.");
				}
				}
			else
			{
				errorMnozstvi.setText(odecetMnozstvi.getText() + " není správné množství!");		
			}
	}
	
	public void zpetNaSklad() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladDetailPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
}