package com.github.Unbearables.kuchyn.process;

import java.util.List;

/**
 * T��da menu p�edstavuje denn� menu v dan� restauraci. Skl�d� se ze
 * String datum, co� ozna�uje datum, na kter� se dan� menu vytv���, list
 * recept� ve form� String, tedy recepty, kter� jsou k dispozici v sekci
 * s recepty a boolean hotovo, zda je menu hotov� nebo nen� hotov�
 * @author David Ho��k
 * @version 1.0.0
 * @created 21.5.2018
 */
public class Menu 
{
	private String datum;
	private List<String> recepty;
	private boolean hotovo;
	
	public Menu(String datum, List<String> recepty) 
	{
		this.datum = datum;
		this.recepty = recepty;
		this.hotovo = false;
	}
	
	/**
	 * Vr�t� datum pro ur�it� menu.
	 * @return String datum menu
	 */
	public String getDatum() 
	{
		return datum;
	}
	
	/**
	 * Metoda vr�t� v�echny recepty v menu
	 * @return String recepty obsa�en� v menu
	 */
	public List<String> getRecepty() 
	{
		return recepty;
	}
	
	/**
	 * Vrac� hodnotu boolean, zda je menu hotov� nebo nen�.
	 * @return True/False
	 */
	public boolean getHotovo() 
	{
		return hotovo;
	}
	
	/**
	 * Metoda, kter� nastavuje hodnotu True/False, podle toho, zda je menu hotov� nebo nen�.
	 * @param bool Boolean hodnota True/False 
	 */
	public void setHotovo(boolean bool) 
	{
		hotovo = bool;
	}
}
