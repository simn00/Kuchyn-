package com.github.Unbearables.kuchyn.process;

import java.util.List;

/**
 * T��da Recept obsahuje �daje o ka�d�m jednotliv�m receptu. Obsahuje 
 * String nazev, n�zev receptu, String chod, nap�. sn�dan�, p�edkrm, atd.,
 * float cena, cena receptu, int doba, doba pot�ebn� k uva�en� receptu,
 * List se surovinami ve Stringu, list pot�en�ch surovin, String 
 * poznamka, pozn�mka o receptu, int pocetPorci, po�et porc�
 * @author David Ho��k
 * @version 1.0.0
 * @created 21.5.2018
 */

public class Recept {

	private String nazev;
	private String chod;
	private float cena;
	private int doba;
	private List<String> suroviny;
	private String poznamka;
	
	private int pocetPorci;
	
	public Recept(String nazev, String chod, float cena, int doba, List<String> suroviny, String poznamka) 
	{
		this.nazev = nazev;
		this.chod = chod;
		this.cena = cena;
		this.doba = doba;
		this.suroviny = suroviny;
		this.poznamka = poznamka;
	}
	
	/**
	 * Vr�t� n�zev receptu.
	 * @return String nazev receptu
	 */
	public String getNazev() 
	{
		return nazev;
	}
	
	/**
	 * Nastavuje n�zev receptu.
	 * @param naz String n�zev receptu, kter� chceme nastavit
	 */
	public void setNazev(String naz) 
	{
		nazev = naz;
	}
	
	/**
	 * Vr�t� typ chodu dan�ho receptu.
	 * @return String chod receptu
	 */
	public String getChod() 
	{
		return chod;
	}
	
	/**
	 * Vr�t� cenu receptu.
	 * @return float cena receptu
	 */
	public float getCena() 
	{
		return cena;
	}
	
	/**
	 * Vr�t� dobu pot�ebnou k uva�en� receptu.
	 * @return int doba pot�ebn� k uva�en� receptu
	 */
	public int getDoba() 
	{
		return doba;
	}
	
	/**
	 * Vr�t� List se surovinami, ze kter�ch se recept skl�d�.
	 * @return List se surovinami ve Stringu
	 */
	public List<String> getSuroviny()
	{
		return suroviny;
	}
	
	/**
	 * Vr�t� text pozn�mky.
	 * @return String poznamka o receptu
	 */
	public String getPoznamka() 
	{
		return poznamka;
	}
	
	/**
	 * Nastav� pozn�mku k receptu
	 * @param pozn String pozn�mka o dan�m receptu
	 */
	public void setPoznamka(String pozn) 
	{
		poznamka = pozn;
	}
	
	/**
	 * Vrac� hodnotu ve Stringu
	 */
	public String toString() 
	{
		return nazev;
	}
	
	/**
	 * Vrac� po�et porc� receptu
	 * @return int pocetPorci
	 */
	public int getPocetPorci() 
	{
		return pocetPorci;
	}
	
	/**
	 * Nastavuje po�et porc� receptu
	 * @param pocPorci int pocetPorci
	 */
	public void setPocetPorci(int pocPorci) 
	{
		pocetPorci = pocPorci;
	}
}
