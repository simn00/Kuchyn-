package com.github.Unbearables.kuchyn.process;

import java.util.List;

public class Recept {

	private String nazev;
	private String chod;
	private float cena;
	private int doba;
	private List<String> suroviny;
	private String poznamka;
	
	private int pocetPorci;
	
	public Recept(String nazev, String chod, float cena, int doba, List<String> suroviny, String poznamka) 
	{
		this.nazev = nazev;
		this.chod = chod;
		this.cena = cena;
		this.doba = doba;
		this.suroviny = suroviny;
		this.poznamka = poznamka;
	}
	
	public String getNazev() 
	{
		return nazev;
	}
	
	public void setNazev(String naz) 
	{
		nazev = naz;
	}
	
	public String getChod() 
	{
		return chod;
	}
	
	public float getCena() 
	{
		return cena;
	}
	
	public int getDoba() 
	{
		return doba;
	}
	
	public List<String> getSuroviny()
	{
		return suroviny;
	}
	
	public String getPoznamka() 
	{
		return poznamka;
	}
	
	public void setPoznamka(String pozn) 
	{
		poznamka = pozn;
	}
	
	public String toString() 
	{
		return nazev;
	}
	
	public int getPocetPorci() 
	{
		return pocetPorci;
	}
	
	public void setPocetPorci(int pocPorci) 
	{
		pocetPorci = pocPorci;
	}
}
