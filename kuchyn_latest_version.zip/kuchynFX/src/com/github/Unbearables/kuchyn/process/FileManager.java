package com.github.Unbearables.kuchyn.process;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.filechooser.FileSystemView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.google.gson.*;
import com.google.gson.stream.JsonReader;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.draw.DottedLineSeparator;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 * 	T��da FileManager se star� o procesy z hlediska zapisov�n� a �ten� datab�ze JSON, 
 * 	generov�n� exportovan�ch dokument�, alokov�n� soubor� a ostatn�...
 * 
 *  Třída FileManager je jádro aplikační logiky a její mozek.
 * 
 * @author David Ho��k, Tom� Bu�ek, Barbara ���kov�, Milan Stehl�k, Nikol ��mov�
 * @version 1.0.0
 * @created 21.5.2018
 */
public class FileManager {

	public File mainTxt;
	private File receptyJSON;
	private File menuJSON;
	private File skladJSON;
	List<String> mainTxtInfo = new ArrayList<String>();
	
	public boolean firstStart = true;
	private PrintWriter writer;
	private String kitchenName;
	private String kitchenType;
	private String kitchenIco;
	
	private JSONArray receptyArray;
	private JSONArray skladArray;
	private JSONArray menuArray;

	private ObservableList<Recept> recepty;
	private ObservableList<Sklad> sklad;
	private Recept clickedRecept;
	private Sklad clickedSklad;
	private String clickedMenuDatum;
	
	private Menu menuActual;
	private List<Menu> menuList;
	
	private String today;
	private DateTimeFormatter dtf;
	
	public static final int DELKA_POZN = 150;
	
	private final JFileChooser fc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());
	
	/**
	 * Zakladni metoda, vola se na na vytvoreni nove instance
	 */
	public void initialize() throws FileNotFoundException, JSONException 
	{
		//create appdata folder
		File appdata = new File(System.getProperty("user.home") + "/Kuchyn_data");
		
		if(!appdata.exists()) 
		{
			new File(System.getProperty("user.home") + "/Kuchyn_data").mkdir();
		}
		
		mainTxt = new File(System.getProperty("user.home") + "/Kuchyn_data/company_info.txt");
		receptyJSON = new File(System.getProperty("user.home") + "/Kuchyn_data/recepty.json");
		menuJSON = new File(System.getProperty("user.home") + "/Kuchyn_data/menu.json");
		skladJSON = new File(System.getProperty("user.home") + "/Kuchyn_data/sklad.json");
		
		menuList = new ArrayList<Menu>();
		
		receptyArray = new JSONArray();
		skladArray = new JSONArray();
		menuArray = new JSONArray();
		getJSONToObsList();
		getJSONToSklad();		
		
		LocalDateTime dateTime = LocalDateTime.now();
		dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		today = dateTime.format(dtf);
		getJSONToMenu();
		
		if(!mainTxt.exists() || mainTxt.length() == 0) 
		{
			System.out.println("file doesn't exist or is empty, creating one");
		}
		else
		{
			//read existing file
			try 
			{
				BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(mainTxt), "UTF8"));
				String line = reader.readLine();
				
				while (line != null) 
				{
					mainTxtInfo.add(line);
					line = reader.readLine();
				}
				reader.close();
			}
			catch (IOException e) {}
			
			//set variables
			kitchenName = mainTxtInfo.get(0);
			kitchenType = mainTxtInfo.get(1);
			kitchenIco = mainTxtInfo.get(2);
			
			firstStart = false;
		}
	}
	
	//take parameters
	/**
	 * Metoda vytvari textovy dokument a zapisuje do nej informace o kuchyni, ktere jsou vyuzivany pozdeji
	 * 
	 * @param companyName nazev kuchyne
	 * @param companyType typ kuchyne
	 * @param companyICO ICO kuchyne/podniku/firmy
	 */
	public void createMainTxt(String companyName, String companyType, String companyICO) 
	{
		try 
		{
			writer = new PrintWriter(mainTxt, "UTF-8");
			kitchenName = companyName;
			kitchenType = companyType;
			kitchenIco = companyICO;
			writer.println(companyName);
			writer.println(companyType);
			writer.println(companyICO);			
			writer.close();
		}
		catch (IOException ex) {}		
	}
		
	/**
	 * Metoda zapise recept do JSON databaze
	 * 
	 * @param obj upraveny recept ktery se vepise do JSONArray a nasledne do JSON souboru
	 */
	public void writeRecept(JSONObject obj) 
	{
		try (PrintWriter writer = new PrintWriter(new FileOutputStream(receptyJSON,false)))
		{
			receptyArray.put(obj);
			writer.write(receptyArray.toString());
		} 
		catch(IOException e) {}
	}
		
	/**
	 * Metoda nastini pohled do JSON databaze pomoci jeho parsovani
	 * 
	 * @return ObservableList<Recept> ktery je pouzivan pro vytvoreni nahledu do databaze receptu
	 */
	public ObservableList<Recept> getJSONToObsList() throws FileNotFoundException, JSONException
	{
		//if json isnt empty
		if(receptyJSON.length() > 3)
		{
			recepty = FXCollections.observableArrayList();

			Gson gson = new Gson();
			JsonReader reader = new JsonReader(new FileReader(receptyJSON));
			Recept[] test = gson.fromJson(reader, Recept[].class);
			
			if(receptyArray.length() == 0)
			{
				for(int j=0; j < test.length; j++)
				{
					JSONObject obj = new JSONObject();
					
					obj.put("nazev", test[j].getNazev());
					obj.put("chod", test[j].getChod());
					obj.put("suroviny", test[j].getSuroviny());
					obj.put("cena", test[j].getCena());
					obj.put("doba", test[j].getDoba());
					obj.put("poznamka", test[j].getPoznamka());
					
					receptyArray.put(obj);
				}
			}
			
			for(int i=0; i < test.length; i++)
			{
				recepty.add(test[i]);
			}
			
			return recepty;
		}
		return null;
	}
	
	/**
	 * Metoda, ktera cte JSON databazi a naplni tak menuList
	 */
	public void getJSONToMenu() throws FileNotFoundException, JSONException
	{
		//if json isnt empty
		if(menuJSON.length() > 3)
		{
			Gson gson = new Gson();
			JsonReader reader = new JsonReader(new FileReader(menuJSON));
			Menu[] test = gson.fromJson(reader, Menu[].class);
			
			//naplnění
			for(int j=0; j < test.length; j++)
			{
				menuList.add(test[j]);
			}
		}
		else
		{
			System.out.println("menuJSON neexsituje");
		}
	}
		
	/**
	 * Metoda vrati odpovidajici menu z menuListu 
	 * 
	 * @param datum odpovidajici identifikator menu, ktere hledame
	 * @return hledane menu (muze byt null)
	 */
	public Menu getMenu(String datum) 
	{
		menuActual = null;
		
		if(!menuList.isEmpty()) 
		{
			for(int j=0; j < menuList.size(); j++) 
			{
				if(menuList.get(j).getDatum().equals(datum))
				{
					menuActual = menuList.get(j);
					return menuActual;
				}
			}
		}
		return null;
	}
	
	/**
	 * Metoda zapise menuList do JSON databaze
	 */
	public void writeMenu() 
	{
		try (PrintWriter writer = new PrintWriter(new FileOutputStream(menuJSON,false)))
		{
			menuArray = new JSONArray(menuList);
			writer.write(menuArray.toString());
		} 
		catch(IOException e) {}
	}
	
	/**
	 * Metoda prida Menu do menuList
	 * 
	 * @param menu pridavane Menu
	 */
	public void addToMenu(Menu menu) 
	{
		menuList.add(menu);
	}
	
	/**
	 * Metoda odstranujici Menu z menuList a nasledne vola metodu, ktera zapise zmenu do JSON databaze
	 * 
	 * @param menu odstranovane Menu
	 */
	public void removeFromMenu(Menu menu) 
	{
		menuList.remove(menu);
		writeMenu();
	}
	
	/**
	 * Metoda pro ziskani existujicich Menu - menuList
	 * 
	 * @return menuList, existujici Menu
	 */
	public List<Menu> getMenues()
	{
		return menuList;
	}
	
	/**
	 * Metoda pro zapisovani suroviny do skladu, touto metodou je mozno odecist nebo pricist existujici surovinu
	 * 
	 * @param nazev nazev suroviny, kterou chceme zmenit
	 * @param mnoz mnozstvi o ktere chceme surovinu zmenit
	 * @param jednotka jednotka suroviny
	 * @param odecti boolean, ktery metode rekne, zda ma pricist nebo odecist (true = odecte, false = pricte)
	 */
	public void writeSklad(String nazev, float mnoz, String jednotka, boolean odecti) throws JSONException 
	{
		boolean pomocna = false;
		Sklad test = null;
		int cislo = 0;
		
		if(sklad != null)
		{
			for(int i=0; i < sklad.size(); i++)
			{
				if(sklad.get(i).getNazev().equals(nazev))
				{
					test = sklad.get(i);
					pomocna = true;
					cislo = i;
					break;
				}
			}
		}
			
		JSONObject obj = new JSONObject();
		
		if(!pomocna)
		{
			try (PrintWriter writer = new PrintWriter(new FileOutputStream(skladJSON,false)))
			{
				obj.put("nazev", nazev);
				obj.put("mnozstvi", mnoz);
				obj.put("jednotka", jednotka);
				skladArray.put(obj);
				writer.write(skladArray.toString());
			} 
			catch(IOException e) {}
		}
		else
		{
			try (FileWriter writer = new FileWriter(skladJSON,false))
			{	
				if(odecti)
				{	
					sklad.get(cislo).deleteMnozstvi(mnoz);
				}
				else
				{	
					sklad.get(cislo).addMnozstvi(mnoz);
				}
				skladArray = new JSONArray(sklad);
				writer.write(skladArray.toString());
			}
			catch(IOException e) {}
		}
	}
	
	/**
	 * Metoda pro upraveni existujiciho receptu a pote provedeni uprav do JSON databaze
	 * 
	 * @param newRec nove zapisovany Recept
	 * @param oldRec Recept, ktery je upravovan
	 */
	public void upravaRecept(Recept newRec, String oldRec) throws JSONException 
	{	
		if(recepty != null)
		{
			for(int i=0; i < recepty.size(); i++)
			{
				if(recepty.get(i).getNazev().equals(oldRec))
				{
					recepty.remove(i);
					break;
				}
			}
		
			//alter it remove the old one from receptyArray, then put it in
			recepty.add(newRec);
		
			try (FileWriter writer = new FileWriter(receptyJSON,false))
			{
				receptyArray = new JSONArray(recepty);
				writer.write(receptyArray.toString());
			}
			catch(IOException e) {}
			
			//iterate through menu and alter every occurence of recept
			for(int i=0; i < menuList.size(); i++) 
			{
				for(int j=0; j < menuList.get(i).getRecepty().size(); j++) 
				{
					String[] split = menuList.get(i).getRecepty().get(j).split("_");
					
					if(oldRec != null) 
					{
						if(split[0].equals(oldRec)) 
						{
							menuList.get(i).getRecepty().remove(oldRec + "_" + split[1]);
							menuList.get(i).getRecepty().add(newRec.getNazev() + "_" + split[1]);
									
							try (FileWriter writer = new FileWriter(menuJSON,false))
							{
								menuArray = new JSONArray(menuList);
								writer.write(menuArray.toString());
							}
							catch(IOException e) {}
						}
					}
				}
			}
		}
	}
	
	/**
	 * Metoda pro upravu Menu a jeji zapsani do JSON databaze
	 * 
	 * @param menu menu, ktere chci upravit
	 */
	public void upravaMenu(Menu menu) throws JSONException 
	{	
		if(menuList != null)
		{
			for(int i=0; i < menuList.size(); i++)
			{
				if(menuList.get(i).getDatum().equals(clickedMenuDatum))
				{
					menuList.remove(i);
					break;
				}
			}
		}
		
		//alter it, remove the old one from menuArray, then put it in
		menuList.add(menu);
		
		try (FileWriter writer = new FileWriter(menuJSON,false))
		{
			menuArray = new JSONArray(menuList);
			writer.write(menuArray.toString());
		}
		catch(IOException e) {}
	}
	
	/**
	 * Metoda precte JSON databazi a naplni ObservableList<Sklad> sklad
	 * 
	 * @return ObservableList<Sklad> sklad, dava nahled do JSON databaze
	 */
	public ObservableList<Sklad> getJSONToSklad() throws FileNotFoundException, JSONException
	{
		//if json isnt empty
		if(skladJSON.length() > 3)
		{
			sklad = FXCollections.observableArrayList();

			Gson gson = new Gson();
			JsonReader reader = new JsonReader(new FileReader(skladJSON));
			Sklad[] test = gson.fromJson(reader, Sklad[].class);
			
			if(skladArray.length() == 0)
			{
				for(int j=0; j < test.length; j++)
				{
					JSONObject obj = new JSONObject();
					
					obj.put("nazev", test[j].getNazev());
					obj.put("mnozstvi", test[j].getMnozstvi());
					obj.put("jednotka", test[j].getJednotka());
					
					skladArray.put(obj);
				}
			}
			
			for(int i=0; i < test.length; i++)
			{
				sklad.add(test[i]);
			}

			return sklad;
		}
		return null;
	}
		
	/**
	 * Metoda odstranuje surovinu ze Skladu a upravu zanese do JSON databaze
	 * 
	 * @param skladS Sklad, ktery odstranujeme
	 */
	public void odstranSkladJSON(Sklad skladS) throws JSONException 
	{
		sklad.remove(skladS);
		
		for(int i=0; i < skladArray.length(); i++) 
		{	
			if(skladArray.getJSONObject(i).get("nazev").equals(skladS.getNazev())) 
			{
				skladArray.remove(i);
				break;
			}
		}
		
		try (PrintWriter writer = new PrintWriter(new FileOutputStream(skladJSON,false)))
		{
			writer.write(skladArray.toString());
		} 
		catch(IOException e) {}
	}
	
	/**
	 * Metoda odstranuje Recept z recepty a pote z databaze JSON
	 * 
	 * @param recept odstranovany Recept
	 */
	public void odstranReceptJSON(Recept recept) throws JSONException 
	{
		recepty.remove(recept);
		
		for(int i=0; i < receptyArray.length(); i++) 
		{	
			if(receptyArray.getJSONObject(i).get("nazev").equals(recept.getNazev())) 
			{
				receptyArray.remove(i);
				break;
			}
		}
		
		//iterate through menu and remove every occurence of recept
		for(int i=0; i < menuList.size(); i++) 
		{
			for(int j=0; j < menuList.get(i).getRecepty().size(); j++) 
			{
				String[] split = menuList.get(i).getRecepty().get(j).split("_");
				
				if(split[0].equals(recept.getNazev())) 
				{
					menuList.get(i).getRecepty().remove(j);
					
					try (FileWriter writer = new FileWriter(menuJSON,false))
					{
						menuArray = new JSONArray(menuList);
						writer.write(menuArray.toString());
					}
					catch(IOException e) {}
				}
			}
		}
		
		try (PrintWriter writer = new PrintWriter(new FileOutputStream(receptyJSON,false)))
		{
			writer.write(receptyArray.toString());
		} 
		catch(IOException e) {}
	}
	
	/**
	 * Metoda vytvari txt soubor s potrebnymi surovinami na dane menu
	 * 
	 * @param suroviny List s danymi surovinami na dane Menu
	 * @param datum Menu datum
	 */
	public void createMenuSurTxt(List<String> suroviny, String datum)
	{	
		String nazevTxt = "Menu na " + datum + ".txt";
		
		fc.setDialogTitle("Export pot�ebn�ch suorvin pro menu");
		FileNameExtensionFilter filter = new FileNameExtensionFilter("Textov� dokument", "txt");
		fc.setFileFilter(filter);
		fc.setSelectedFile(new File(nazevTxt));
		int response = fc.showSaveDialog(null);
		
		if(response == JFileChooser.APPROVE_OPTION) 
		{
			File surNeed;
			
			if(!fc.getSelectedFile().getName().substring(fc.getSelectedFile().getName().length() - 4).equals(".txt")) 
			{
				surNeed = new File(fc.getSelectedFile().getAbsoluteFile().toString() + ".txt");
			}
			else 
			{
				surNeed = fc.getSelectedFile();
			}
			
			try 
			{
				writer = new PrintWriter(surNeed, "UTF-8");
				
				for(int i=0; i < suroviny.size(); i++) 
				{
					writer.println(suroviny.get(i));
				}
				writer.close();
			}
			catch (IOException ex) {}
		}
	}
	
	/**
	 * Metoda exportuje Menu do do PDF s danou sablonou, pouziva itext externi knihovnu
	 * 
	 * @param datum datum identifikator pro Menu
	 * @param recepty dane recepty, ktere je potreba zapsat do PDF
	 */
	public void createPdf(String datum, List<Recept> recepty) throws FileNotFoundException, DocumentException
	{
		String nazevPdf = "Menu na " + datum + ".pdf";
		
		fc.setDialogTitle("Export menu do pdf");
		FileNameExtensionFilter filter = new FileNameExtensionFilter("PDF", "pdf");
		fc.setFileFilter(filter);
		fc.setSelectedFile(new File(nazevPdf));
		int response = fc.showSaveDialog(null);
		
		if(response == JFileChooser.APPROVE_OPTION) 
		{
			File menuPdf;
			
			if(!fc.getSelectedFile().getName().substring(fc.getSelectedFile().getName().length() - 4).equals(".pdf")) 
			{
				menuPdf = new File(fc.getSelectedFile().getAbsoluteFile().toString() + ".pdf");
			}
			else 
			{
				menuPdf = fc.getSelectedFile();
			}
			
	        Document document = new Document(PageSize.A4);
	        PdfWriter.getInstance(document, new FileOutputStream(menuPdf));
	        document.open();
	        
	        Font kitchen =  FontFactory.getFont(FontFactory.TIMES_BOLD,"Cp1250", 18, Font.BOLD,BaseColor.BLACK);
	        Font kitTyp = FontFactory.getFont(FontFactory.TIMES,"Cp1250", 12, Font.ITALIC,BaseColor.BLACK);
	        Font headers =  FontFactory.getFont(FontFactory.TIMES_BOLD,"Cp1250", 16, Font.BOLD,BaseColor.BLACK);
	        Font meals = FontFactory.getFont(FontFactory.TIMES_BOLD, "Cp1250",12, Font.NORMAL,BaseColor.BLACK);
	        Font basic = FontFactory.getFont(FontFactory.TIMES, "Cp1250",10, Font.NORMAL,BaseColor.BLACK);
	        Font footer = FontFactory.getFont(FontFactory.TIMES, "Cp1250",10, Font.ITALIC,BaseColor.BLACK);
	        
	        Paragraph jmeno = new Paragraph(kitchenName, kitchen);
	        jmeno.setAlignment(Element.ALIGN_CENTER);
	        Paragraph typ = new Paragraph("( " + kitchenType + " )", kitTyp);
	        typ.setAlignment(Element.ALIGN_CENTER);
	        document.add(jmeno);
	        document.add(typ);
	        
	        document.add(new Paragraph("Denn� menu na " + datum, headers));
	        document.add(new Paragraph(" "));
	        document.add(new Paragraph(" "));
	        
	        for(int i=0; i < recepty.size(); i++)
	        {
	        	document.add(new Paragraph(" "));
	        	Paragraph jidlo = new Paragraph("J�dlo " + (i+1), meals);
	        	document.add(jidlo);
	        	int vaha = 0;
	        	
	        	for(int j=0; j < recepty.get(i).getSuroviny().size(); j++) 
	        	{
	        		String[] sur = recepty.get(i).getSuroviny().get(j).split("_");
	        		vaha += Integer.parseInt(sur[1]);
	        	}
	        	
	        	Paragraph recept = new Paragraph(recepty.get(i).getNazev() + ", (" + vaha + "g)", basic);
	        	DottedLineSeparator separator = new DottedLineSeparator();
	        	Chunk c = new Chunk(separator);
	        	String cena = recepty.get(i).getCena() + "K�";
	        	recept.add(c);
	        	recept.add(cena);
	        	document.add(recept);
	        	document.add(new Paragraph(" "));
	        }
	
	        document.add(new Paragraph(" "));
	        document.add(new Paragraph(" "));
	        Paragraph dc = new Paragraph("P�ejeme v�m dobrou chu�.", footer);
	        dc.setAlignment(Element.ALIGN_CENTER);
	        document.add(dc);
	        document.close();
		}
	}
	
	/**
	 * Metoda, ktera zmeni promennou clickedMenDatum pro lehci navigaci
	 * 
	 * @param datum identifikator Menu
	 */
	public void setClickedMenuDatum(String datum) 
	{
		clickedMenuDatum = datum;
	}
	
	/**
	 * Metoda, ktera vrati promennou clickedMenDatum pro lehci navigaci
	 * 
	 * @return datum jako String
	 */
	public String getClickedMenuDatum() 
	{
		return clickedMenuDatum;
	}
	
	/**
	 * Metoda pro vraceni receptu
	 * 
	 * @return existujici recepty
	 */
	public ObservableList<Recept> getRecepty()
	{
		return recepty;
	}
	
	/**
	 * Metoda vrati vsechny surovinu na Skladu
	 * 
	 * @return suroviny na Skladu
	 */
	public ObservableList<Sklad> getSklad()
	{
		return sklad;
	}
	
	/**
	 * Metoda zmeni prommenou clickedSklad pro lehci navigaci
	 * 
	 * @param sklad Sklad na ktery detail chci projit
	 */
	public void setClickedSklad(Sklad sklad) 
	{
		clickedSklad = sklad;
	}
	
	/**
	 * Metoda vrati clickedSklad
	 * 
	 * @return Sklad
	 */
	public Sklad getClickedSklad() 
	{
		return clickedSklad;
	}
	
	/**
	 * Metoda zmeni prommenou clickedRecept pro lehci navigaci
	 * 
	 * @param recept Recept na ktery detail chci projit
	 */
	public void setClickedRecept(Recept recept) 
	{
		clickedRecept = recept;
	}
	
	/**
	 * Metoda vrati clickedRecept
	 * 
	 * @return Recept
	 */
	public Recept getClickedRecept() 
	{
		return clickedRecept;
	}
	
	/**
	 * Metoda oznaci, ze uzivatel neni v aplikaci poprve
	 * 
	 * @param start boolean, true = poprve v aplikaci, false = jiz v aplikaci byl
	 */
	public void setFirstStart(boolean start) 
	{
		firstStart = start;
	}
	
	/**
	 * Metoda vr�t��, jestli je u�ivatel v aplikaci poprv�
	 * 
	 * @return boolean, true = poprve v aplikaci, false = jiz v aplikaci byl
	 */
	public boolean getFirstStart() 
	{
		return firstStart;
	}
	
	/**
	 * Vrati jmeno kuchyne, ktere sam uzivatel zadal
	 * 
	 * @return String jmeno kuchyne
	 */
	public String getKitchenName() 
	{
		return kitchenName;	
	}
	
	/**
	 * Vrati typ kuchyne, ktery sam uzivatel zvolil
	 * 
	 * @return String typ kuchyne
	 */
	public String getKitchenType() 
	{
		return kitchenType;	
	}
	
	/**
	 * Vrati ICO kuchyne, ktery sam uzivatel zadal
	 * 
	 * @return String ICO kuchyne (neni int protoze to neni nutne)
	 */
	public String getKitchenIco() 
	{
		return kitchenIco;
	}
	
	/**
	 * Metoda vrati dnesni datum formatovatene pomoci dtf
	 * 
	 * @return String datumu
	 */
	public String getToday() 
	{
		return today;
	}
}