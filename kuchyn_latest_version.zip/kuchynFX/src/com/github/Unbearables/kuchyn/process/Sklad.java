package com.github.Unbearables.kuchyn.process;

/**
 * T��da Sklad obsahuje �daje o surovin�ch, kter� se nach�z�
 * ve skladu. Obsahuje String nazev, n�zev suroviny obsa�en� ve skladu,
 * float mnozstv�, mno�stv� suroviny, kter� je k dispozici ve skladu,
 * String jednotka, jednotka, ve kter� se surovina ve skladu nach�z�
 * @author Tom� Bu�ek
 * @version 1.0.0
 * @created 21.5.2018
 */
public class Sklad {

	private String nazev;
	private float mnozstvi;
	private String jednotka;
	
	public Sklad(String nazev, float mnozstvi, String jednotka)
	{
		this.nazev = nazev;
		this.mnozstvi = mnozstvi;
		this.jednotka = jednotka;
	}
	
	/**
	 * Vr�t� n�zev suroviny ve skladu.
	 * @return String nazev, n�zev suroviny ve skladu
	 */
	public String getNazev() 
	{
		return nazev;
	}
	
	/**
	 * Vr�t� mno�stv� suroviny ve skladu.
	 * @return float mnozstvi, mno�stv� suroviny ve skladu
	 */
	public float getMnozstvi() 
	{
		return mnozstvi;
	}
	
	/**
	 * Vr�t� jednotku suroviny ve skladu.
	 * @return String jednotka, jednotka suroviny ve skladu
	 */
	public String getJednotka() 
	{
		return jednotka;
	}
	
	/**
	 * Vrac� hodnotu ve Stringu
	 */
	public String toString() 
	{
		return nazev;
	}
	
	/**
	 * Nastav� mno�stv� suroviny ve skladu.
	 * @param mnoz float mno�stv� suroviny ve skladu
	 */
	public void setMnozstvi(float mnoz)
	{
		this.mnozstvi = mnoz;
	}

	/**
	 * P�id� zadan� mno�stv� k ji� dan�mu mno�stv� konkr�tn� suroviny ve skladu.
	 * @param mnozToAdd float mno�stv�, kter� chceme p�idat
	 */
	public void addMnozstvi(float mnozToAdd) 
	{
		mnozstvi += mnozToAdd;
	}
	
	/**
	 * Odebere zadan� mno�stv� od ji� dan�ho mno�stv� konkr�tn� suroviny ve skladu.
	 * @param mnozToDelete float mno�stv�, kter� chceme odebrat
	 */
	public void deleteMnozstvi(float mnozToDelete) 
	{
		mnozstvi -= mnozToDelete;
	}	
	
}
