package com.github.Unbearables.kuchyn.process;

/**
 * T��da Sklad obsahuje �daje o surovin�ch. Obsahuje String nazev, n�zev
 * suroviny, String jednotka, jednotka suroviny,
 * float cena, cena suroviny, int alergen, alergeny suroviny
 * float mnozstvi, mno�stv� suroviny.
 * @author Tom� Bu�ek
 * @version 1.0.0
 * @created 21.5.2018
 */

public class Surovina {

	private String nazev;
	private String jednotka;
	private float cena;
	private int alergen;
	private float mnozstvi;
	
	public Surovina(String nazev, String jednotka) 
	{
		this.nazev = nazev;
		this.jednotka = jednotka;
	}
	
	/**
	 * Vr�t� mno�stv� suroviny.
	 * @return float mnozstvi, mno�stv� suroviny
	 */
	public float getMnozstvi() 
	{
		return mnozstvi;
	}
	
	/**
	 * Nastav� mno�stv� suroviny.
	 * @param mnozstviSur float, mno�stv� suroviny, kter� chceme nastavit
	 */
	public void setMnozstvi(float mnozstviSur) 
	{
		mnozstvi = mnozstviSur;
	}
	
	/**
	 * P�id� zadan� mno�stv� k ji� dan�mu mno�stv� konkr�tn� suroviny.
	 * @param mnozToAdd float mno�stv�, kter� chceme p�idat
	 */
	public void addMnozstvi(float mnozToAdd) 
	{
		mnozstvi += mnozToAdd;
	}
	
	/**
	 * Vr�t� n�zev suroviny.
	 * @return String nazev, n�zev suroviny
	 */
	public String getNazev() 
	{
		return nazev;
	}
	
	/**
	 * Vr�t� jednotku suroviny.
	 * @return String jednotka, jednotka suroviny
	 */
	public String getJednotka() 
	{
		return jednotka;
	}
	
	/**
	 * Vrac� hodnotu ve Stringu
	 */
	public String toString() 
	{
		return nazev;
	}
}
