package com.github.Unbearables.kuchyn.ui;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import application.Start;
import com.github.Unbearables.kuchyn.process.FileManager;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainWindowController extends AnchorPane
{
	@FXML private AnchorPane mainWPane;
	@FXML private Label testLabel;
	@FXML private Label kitchenName;
	@FXML private Label kitchenType;
	@FXML private ImageView logo;
	
	private FileManager fileManager = Start.fileManager;
	private FXMLLoader loader;

	public void initialize() 
	{
		kitchenName.setText(fileManager.getKitchenName());
		kitchenType.setText(fileManager.getKitchenType());
		loader = new FXMLLoader();
		
		Image img = new Image("/logo.png");
		logo.setImage(img);
	}
	
	public void otevriMenuOverview() throws IOException 
	{
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_Menu.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (mainWPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void otevriReceptyOverview() throws IOException
	{
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_Recepty.fxml"));		
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (mainWPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void otevriSkladOverview() throws IOException
	{
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));		
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (mainWPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void otevriKuchynInfo() throws IOException
	{
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_FirstStart.fxml"));		
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (mainWPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
}