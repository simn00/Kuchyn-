package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import application.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Recept;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ReceptDetailController
{
	@FXML private AnchorPane detailRecPane;
	@FXML private TextField nazev;
	@FXML private ChoiceBox<String> chod;
	@FXML private TextField cena;
	@FXML private TextField dobaTrvani;
	@FXML private TextArea poznamka;
	@FXML private VBox upravaSur;
	@FXML private ListView<String> seznamSurovin;
	@FXML private Button zpetBtn;
	@FXML private Button upravitBtn;
	@FXML private TextField nazSur;
	@FXML private TextField mnozSur;
	@FXML private ChoiceBox<String> jednSur;
	@FXML private Label poznamkaCounter;
	@FXML private Label errorLabel;
	
	private FileManager fileManager = Start.fileManager;
	
	private Recept recept;
	private String oldRec;
	private List<String> surovinyRecept; 
	private List<String> surovinyReceptPuvodni;
	private boolean upravaMode;
	
	private final int DELKA_POZN = fileManager.DELKA_POZN;
	
	public void initialize() 
	{
		recept = fileManager.getClickedRecept();
		
		surovinyRecept = new ArrayList<String>();
		surovinyRecept = recept.getSuroviny();
		
		endUprava();
	}
	
	public void upravitRecept() throws JSONException 
	{
		if(!upravaMode) 
		{
			upravaMode = true;
			chod.getItems().addAll("snídaně","předkrm","polévka","hlavní jídlo","jídlo k pivu","dezert","nápoj");		
			upravaSur.setVisible(true);
			nazev.setEditable(true);
			cena.setEditable(true);
			dobaTrvani.setEditable(true);
			poznamka.setEditable(true);
			upravitBtn.setText("Hotovo");
			zpetBtn.setText("Zrušit");
			jednSur.getItems().addAll("g","ml","ks");
		}
		else 
		{
			if(nazev.getText() != null && cena.getText() != null && dobaTrvani.getText() != null && !surovinyRecept.isEmpty()) 
			{
				//check cena doba
				if(cena.getText().matches("(^[1-9]\\d?\\d?\\d?,\\d\\d?)|(^[1-9]\\d?\\d?\\d?)") && dobaTrvani.getText().matches("^[1-9]\\d*")) 
				{
					//check recept duplicate
					if(!checkForDuplicateRecept()) 
					{
						oldRec = recept.getNazev();
						recept = new Recept(nazev.getText(), chod.getSelectionModel().getSelectedItem(), Float.parseFloat(cena.getText().replaceAll(",", ".")), Integer.parseInt(dobaTrvani.getText()), surovinyRecept, poznamka.getText());
						fileManager.upravaRecept(recept, oldRec);
						
						surovinyReceptPuvodni = new ArrayList<String>();
						surovinyReceptPuvodni = seznamSurovin.getItems();
						
						zpetBtn.setText("Zpět");
						upravitBtn.setText("Upravit");
						endUprava();
					}
					else 
					{
						errorLabel.setText("Recept: " + nazev.getText() + ", již existuje.");
					}
				}
				else 
				{
					errorLabel.setText("Doba nebo cena je špatně.");
				}
			}
			else 
			{
				errorLabel.setText("Prázdné povinné údaje.");
			}
		}
	}
	
	public void zpetNaRecepty() throws IOException 
	{
		if(!upravaMode)
		{
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Recepty.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (detailRecPane.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
		else 
		{
			endUprava();
			zpetBtn.setText("Zpět");
			upravitBtn.setText("Upravit");
		}
	}
	
	public boolean checkForDuplicateRecept()
	{
		ObservableList<Recept> recepty = fileManager.getRecepty();
		
		if(recepty != null) 
		{
			//remove the recept from recepty in checking
			for(int i = 0; i < recepty.size(); i++) 
			{
				if (recepty.get(i).getNazev().toLowerCase().equals(recept.getNazev().toLowerCase().trim().replaceAll(" +", " ")))
				{
					recepty.remove(i);
					break;
				}
			}
			
			for(int i = 0; i < recepty.size(); i++) 
			{
				if (recepty.get(i).getNazev().toLowerCase().equals(nazev.getText().toLowerCase().trim().replaceAll(" +", " ")))
				{
					return true;
				}
			}
		}
		
		return false;
	}
	
	public void endUprava() 
	{
		upravaMode = false;
		errorLabel.setText("");
		chod.getItems().add(recept.getChod());
		chod.setValue(recept.getChod());
		upravaSur.setVisible(false);
		nazev.setEditable(false);
		nazev.setText(recept.getNazev());
		cena.setEditable(false);
		String test = recept.getCena() + "";
		cena.setText(test.replaceAll("\\.", ","));
		dobaTrvani.setEditable(false);
		dobaTrvani.setText(recept.getDoba() + "");
		poznamka.setEditable(false);
		poznamka.setText(recept.getPoznamka());
		poznamkaCounter.setText(DELKA_POZN - poznamka.getLength() + "/" + DELKA_POZN);
		zpetBtn.setVisible(true);
		
		seznamSurovin.getItems().clear();
		surovinyReceptPuvodni = new ArrayList<String>();
		
		for( int i=0 ; i < recept.getSuroviny().size() ; i++ ) 
		{
			surovinyReceptPuvodni.add(recept.getSuroviny().get(i).replaceAll("_", " "));
		}
		
		seznamSurovin.getItems().addAll(surovinyReceptPuvodni);
		seznamSurovin.getSelectionModel().clearSelection();
	}
	
	public void pridejSurovinu() throws JSONException 
	{
		if(mnozSur.getText().matches("(^[1-9]\\d?\\d?,\\d\\d?)|(^[1-9]\\d?\\d?)")) 
		{
			if(nazSur.getText() != null && mnozSur.getText() != null && jednSur.getSelectionModel().getSelectedItem() != null) 
			{
				String viewSurovina = (nazSur.getText() + " " + mnozSur.getText() + " " +  jednSur.getSelectionModel().getSelectedItem()).trim().replaceAll(" +", " ");
				String finalSurovina = (nazSur.getText() + "_" + mnozSur.getText() + "_" + jednSur.getSelectionModel().getSelectedItem()).trim().replaceAll(" +", " ");
				JSONObject sur = new JSONObject();
				sur.put(nazSur.getText().trim().replaceAll(" +", " "), Integer.parseInt(mnozSur.getText().trim().replaceAll(" +", " ")));
				
				boolean surDupl = false;
				
				for (int i=0 ; i < seznamSurovin.getItems().size(); i++) 
				{
					String[] recSur = seznamSurovin.getItems().get(i).split("_");
					
					if(recSur[0].toLowerCase().trim().replaceAll(" +", " ").equals(nazSur.getText().toLowerCase().trim().replaceAll(" +", " "))) 
					{
						surDupl = true;
						break;
					}
				}
				
				if(!surDupl)
				{
					surovinyRecept.add(finalSurovina);
					seznamSurovin.getItems().add(viewSurovina);
					
					//resets input fields
					nazSur.setText(null);
					mnozSur.setText(null);
					jednSur.valueProperty().set(null);
					errorLabel.setText(null);
				}
				else 
				{
					errorLabel.setText("Surovina " + viewSurovina + " je již přidána.");
				}
			}
		}
		else 
		{
			errorLabel.setText("Špatně zadané množství suroviny: " + mnozSur.getText());
			mnozSur.setText(null);
		}
	}
	
	public void poznamkaCountWords() 
	{
		poznamkaCounter.setText(DELKA_POZN - poznamka.getLength() + "/" + DELKA_POZN);
		
		if(poznamka.getLength() > DELKA_POZN) 
		{
			String s = poznamka.getText().substring(0, DELKA_POZN);
			poznamka.setText(s);
			poznamka.positionCaret(DELKA_POZN);
			poznamkaCounter.setText(0 + "/" + DELKA_POZN);
		}
	}
	
	public void odeberSurovinu() throws JSONException 
	{
		if(upravaMode) 
		{
			String odebiranaSurovina = seznamSurovin.getSelectionModel().getSelectedItem();
			seznamSurovin.getItems().remove(odebiranaSurovina);
			
			for(int n = 0; n < surovinyRecept.size(); n++)
			{
			    String surString = surovinyRecept.get(n).toString();
			    
			    if(surString.equals(najdiVSurovinach(odebiranaSurovina))) 
			    {
			    	surovinyRecept.remove(n);
			    	break;
			    }
			}
		}
	}
	
	public String najdiVSurovinach(String surovina) 
	{
		String substring = surovina.substring(surovina.lastIndexOf(" ", surovina.lastIndexOf(" ") - 1));
		String jmenoSur = surovina.replace(substring, "");
		String finSubstring = substring.replaceAll(" +", "_");
		String finalString = jmenoSur + finSubstring;
		return finalString;
	}
}