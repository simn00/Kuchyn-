package com.github.Unbearables.kuchyn.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;

import application.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Menu;
import com.github.Unbearables.kuchyn.process.Recept;
import com.github.Unbearables.kuchyn.process.Sklad;
import com.github.Unbearables.kuchyn.process.Surovina;
import com.itextpdf.text.DocumentException;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.Tooltip;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;

public class MenuController
{
	@FXML private AnchorPane menuPane;
	@FXML private Label todayDate;
	@FXML private DatePicker menuDatePicker;
	@FXML private TableView<Recept> menuTable;
	@FXML private TableView<Surovina> menuSuroviny;
	@FXML private TableColumn<Recept, String> nazevSuroviny;
    @FXML private TableColumn<Recept, String> mnozstviSuroviny;
    @FXML private TableColumn<Recept, String> jednotkaSuroviny;
    @FXML private TableColumn<Recept, String> nazevReceptu;
    @FXML private TableColumn<Recept, String> recPocPorci;
    @FXML private Button actionBtn;
    @FXML private Button odstranitBtn;
    @FXML private Button surNeededBtn;
    @FXML private Button schvalitBtn;
    @FXML private ProgressBar progBar;
    @FXML private Label schvalenoLabel;
    @FXML private Button pdfBtn;
    @FXML private ImageView checkmark;
	
	private FileManager fileManager = Start.fileManager;
	private LocalDate localDate;
	private DateTimeFormatter dtf;
	private List<String> surNeeded;
	private ObservableList<Sklad> sklad;
	private List<Menu> menuList;
	private float surTotal;
	private float surActual;	
	
	private Menu menu;
	private ObservableList<Recept> receptList;
	private ObservableList<Surovina> surovinyList;

	/**
	 * JavaFX zakladni metoda, vola se na inicializovani Scene.
	 */
	public void initialize() throws FileNotFoundException, JSONException
	{
		LocalDateTime dateTime = LocalDateTime.now();
		String fullDate = dateTime.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL));
		String today = fileManager.getToday();
		
		dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		localDate = LocalDate.parse(today, dtf);
		
		sklad = fileManager.getSklad();
		menuList = fileManager.getMenues();
		
		todayDate.setText(fullDate);
		menuDatePicker.setValue(localDate);
		
		//menuTable
		nazevReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("nazev"));
		recPocPorci.setCellValueFactory(new PropertyValueFactory<Recept, String>("pocetPorci"));
		
		//suroviny table
		nazevSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("nazev"));
		mnozstviSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("mnozstvi"));
		jednotkaSuroviny.setCellValueFactory(new PropertyValueFactory<Recept, String>("jednotka"));
		
		Image img = new Image("/checkmark.png");
		checkmark.setImage(img);
		
		updateListView();
		
		//graficky vybarvi datePicker podle toho jestli menu na den je hotovo
		menuDatePicker.setDayCellFactory (new Callback<DatePicker, DateCell>() 
		{
            public DateCell call(final DatePicker datePicker) 
            {
                return new DateCell() 
                {
                    @Override public void updateItem(LocalDate item, boolean empty) {
                        super.updateItem(item, empty);
                        
                        for(int i=0; i < menuList.size(); i++) 
                        {	
                        	if(item.format(dtf).equals(menuList.get(i).getDatum())) 
                            {
                        		Tooltip tooltip = new Tooltip();
        						tooltip.setStyle("-fx-font-size: 12px;");
                        		
                        		if(menuList.get(i).getHotovo()) 
                        		{
                        			tooltip.setText("Menu schváleno!");
                        			setTooltip(tooltip);
                                    setStyle("-fx-background-color: #b3ffb3;");
                        		}
                        		else 
                        		{
                        			tooltip.setText("Menu není hotovo!");
                        			setTooltip(tooltip);
                                    setStyle("-fx-background-color: #ff751a;");
                        		}
                            }
                        }
                    }
                };
            }
        });
	}
	
	/**
	 * Zmeni okno na hlavni okno (zmeni scenu).
	 */
	public void backToTheKitchen() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (menuPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
	/**
	 * Zmeni okno podle aktualniho menu.
	 * Jestli menu na den existuje tak metoda presmeruje uzivatele na jeho zmenu.
	 * Jeslti menu na den neexistuje tak metoda presmeruje uzivatele na vytvoreni noveho menu.
	 */
	public void changeOrCreate() throws IOException
	{
		fileManager.setClickedMenuDatum(menuDatePicker.getValue().format(dtf).toString());
		
		if(menu == null) 
		{
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Menu_New.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (menuPane.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
		else 
		{
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Menu_Change.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (menuPane.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
	}
	
	/**
	 * Prida den aktualni hodnote datePickeru (snadnejsi pristup)
	 */
	public void nextDay() 
	{
		menuDatePicker.setValue(menuDatePicker.getValue().plusDays(1));
	} 
	
	/**
	 * Ubere den z aktualni hodnoty datePickeru (snadnejsi pristup)
	 */
	public void prevDay() 
	{
		menuDatePicker.setValue(menuDatePicker.getValue().minusDays(1));
	}
	
	/**
	 * Metoda se vola na zmenu DatePickeru, updatne vse potrebne k nahledu na zvolene menu datum
	 */
	public void updateListView() throws FileNotFoundException, JSONException 
	{
		menu = fileManager.getMenu(menuDatePicker.getValue().format(dtf).toString());
		menuTable.getItems().clear();
		menuSuroviny.getItems().clear();
		
		if(menu != null) 
		{
			receptList = FXCollections.observableArrayList();
			surovinyList = FXCollections.observableArrayList();
			
			for(int i=0; i < menu.getRecepty().size(); i++) 
			{
				//rec[0] = nazev receptu, rec[1] = pocet porci 
				String[] rec = menu.getRecepty().get(i).split("_");
				
				for(int j=0; j < fileManager.getRecepty().size(); j++) 
				{
					if(rec[0].equals(fileManager.getRecepty().get(j).getNazev())) 
					{
						Recept recept = fileManager.getRecepty().get(j);
						recept.setPocetPorci(Integer.parseInt(rec[1]));
						
						receptList.add(recept);
						
						for(int k=0; k < recept.getSuroviny().size(); k++) 
						{
							boolean dontAdd = false;
							String[] surovina = recept.getSuroviny().get(k).split("_");
							
							Surovina sur = new Surovina(surovina[0], surovina[2]);
							sur.setMnozstvi(Float.parseFloat(surovina[1]));
							
							for(int m=0 ; m < surovinyList.size() ; m++) 
							{	
								if(sur.getNazev().equals(surovinyList.get(m).getNazev()))
								{
									surovinyList.get(m).addMnozstvi(Float.parseFloat(surovina[1]) * recept.getPocetPorci());
									dontAdd = true;
								}
							}
							
							if(!dontAdd) 
							{
								sur.setMnozstvi(sur.getMnozstvi() * recept.getPocetPorci());
								surovinyList.add(sur);
							}
						}
					}
				}
			}
			
			menuTable.setItems(receptList);
			menuSuroviny.setItems(surovinyList);
			
			//graficka uprava menuSuroviny
			menuSuroviny.setRowFactory(surovina -> new TableRow<Surovina>() 
			{
				@Override
				public void updateItem(Surovina sur, boolean empty) 
				{
					super.updateItem(sur, empty);
				        
				    if (sur == null) 
				    {		        	
				    	setStyle("");
				        setTooltip(null);
				    }
				    else 
				    {	
				    	if(!menu.getHotovo())
				    	{
				    		if(sklad != null) 
				    		{
				    			for( int j=0; j < sklad.size(); j++ ) 
								{	
									Tooltip tooltip = new Tooltip();
									tooltip.setStyle("-fx-font-size: 12px;");
									
									Sklad skladSur = sklad.get(j);
										
									if(sur.getNazev().equals(skladSur.getNazev()))
									{
										if(sur.getMnozstvi() > skladSur.getMnozstvi()) 
										{
											//suroviny není dostatek
											setStyle("-fx-background-color: tomato;");
											float nedostatek = sur.getMnozstvi() - skladSur.getMnozstvi();
											tooltip.setText("Chybí " + nedostatek + skladSur.getJednotka());
											setTooltip(tooltip);
										}
										else 
										{
											//surovina je na skladu
											setStyle("");
											tooltip.setText("Na skladu: " + skladSur.getMnozstvi() + skladSur.getJednotka());
											setTooltip(tooltip);
										}
											
										break;
									}
										
									//surovina není na skladu vůbec
									setStyle("-fx-background-color: red;");
									tooltip.setText("Surovina na skladu není!");
									setTooltip(tooltip);
								}
				    		}
				    		else
				    		{
				    			Tooltip tooltip = new Tooltip();
								tooltip.setStyle("-fx-font-size: 12px;");
								
				    			setStyle("-fx-background-color: red;");
								tooltip.setText("Surovina na skladu není!");
								setTooltip(tooltip);
				    		}
				    	}
				    }
				}
			});
		}
		
		updateProg();
		updateNodes();
	}
	
	/**
	 * Metoda zavola odstraneni menu, menu lze odstranit pokud neni schvaleno
	 */
	public void odstranitMenu() throws FileNotFoundException, JSONException 
	{
		//popup
		Alert alert = new Alert(AlertType.WARNING, "Opravdu chcete menu odstranit?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
		alert.setTitle("Odstranění menu");
		alert.setHeaderText("Odstranit menu na den " + menu.getDatum());
		alert.showAndWait();
		
		if(alert.getResult() == ButtonType.YES) 
		{
			fileManager.removeFromMenu(menu);
			updateListView();
		}
	}
	
	/**
	 * Otevre okno (zmeni scenu) s detailem prokliknuteho receptu.
	 */
	public void goToRecept() throws IOException
	{
		Recept receptToGo = menuTable.getSelectionModel().getSelectedItem();
		
		if(receptToGo != null) 
		{
			fileManager.setClickedRecept(receptToGo);
			
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_ReceptDetail.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (menuPane.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
	}
	
	/**
	 * Dynamicky zmeni Nodes podle toho jestli menu na dany den existuje.
	 */
	public void updateNodes() 
	{
		if(menu != null) 
		{
			actionBtn.setVisible(true);
			actionBtn.setText("Změnit menu");
			odstranitBtn.setVisible(true);
			surNeededBtn.setVisible(true);
			schvalenoLabel.setVisible(false);
			checkmark.setVisible(false);
			pdfBtn.setVisible(false);
			schvalitBtn.setVisible(false);
			
			if(progBar.getProgress() == 1) 
			{
				surNeededBtn.setVisible(false);
				
				if(menu.getHotovo()) 
				{
					schvalitBtn.setVisible(false);
					odstranitBtn.setVisible(false);
					actionBtn.setVisible(false);
					schvalenoLabel.setVisible(true);
					checkmark.setVisible(true);
					pdfBtn.setVisible(true);
				}
				else 
				{
					schvalitBtn.setVisible(true);
				}
			}
		}
		else 
		{
			actionBtn.setVisible(true);
			actionBtn.setText("Nové menu");
			odstranitBtn.setVisible(false);
			surNeededBtn.setVisible(false);
			schvalitBtn.setVisible(false);
			schvalenoLabel.setVisible(false);
			checkmark.setVisible(false);
			pdfBtn.setVisible(false);
		}
	}
	
	/**
	 * Metoda spocita celkove suroviny z menu a informuje o celkovem prubehu menu pomoci progressBaru.
	 */
	public void updateProg() 
	{
		if(menu != null) 
		{
			if(menu.getHotovo()) 
			{
				progBar.setProgress(1);
			}
			else 
			{
				surTotal = 0;
				surActual = 0;
				for(int i=0; i < surovinyList.size(); i++) 
				{
					Surovina sur = surovinyList.get(i);
					boolean ko = false;
					
					if(sklad != null) 
					{
						for(int j=0; j < sklad.size(); j++)
						{
							if(sur.getNazev().equals(sklad.get(j).getNazev())) 
							{
								if(sur.getMnozstvi() > sklad.get(j).getMnozstvi())
								{
									//suroviny je malo
									ko = true;
									float nedostatek = sur.getMnozstvi() - sklad.get(j).getMnozstvi();
									surActual += nedostatek;
									surTotal += sur.getMnozstvi();
									break;
								}
								
								//suroviny je dost
								ko = true;
								surTotal += sur.getMnozstvi();
								break;
							}
						}
					}
					
					if(!ko) 
					{
						surActual += sur.getMnozstvi();
						surTotal += sur.getMnozstvi();
					}
				}
				
				progBar.setProgress(1-(surActual/surTotal));
			}
			
			if(progBar.getProgress() == 1) 
			{
				progBar.setStyle("-fx-accent: lightgreen;");
			}
			else 
			{
				progBar.setStyle("-fx-accent: lightblue;");
			}
		}
		else 
		{
			progBar.setProgress(0);
		}
	}
	
	/**
	 * Metoda zkontroluje skutecnosti pro export chybejicich surovin, pote zavola metodu pro samotny export
	 * Metoda se vola po stisknuti tlacitka "Export potrebnych surovin"
	 */
	public void createSurTxt() 
	{
		surNeeded = new ArrayList<String>();
		
		for(int i=0; i < surovinyList.size(); i++) 
		{
			Surovina sur = surovinyList.get(i);
			boolean ko = false;
			for(int j=0; j < sklad.size(); j++)
			{
				if(sur.getNazev().equals(sklad.get(j).getNazev())) 
				{
					if(sur.getMnozstvi() > sklad.get(j).getMnozstvi())
					{
						//suroviny je malo
						ko = true;
						float dokoupit = sur.getMnozstvi() - sklad.get(j).getMnozstvi();
						surNeeded.add(sur.getNazev() + " : " + dokoupit + " " + sur.getJednotka());
						break;
					}
					
					//suroviny je dost
					ko = true;
					break;
				}
			}
			
			if(!ko) 
			{
				surNeeded.add(menuSuroviny.getItems().get(i).getNazev() + " : " + menuSuroviny.getItems().get(i).getMnozstvi() + " " + menuSuroviny.getItems().get(i).getJednotka());
			}
		}

		fileManager.createMenuSurTxt(surNeeded, menuDatePicker.getValue().format(dtf).toString());
	}
	
	/**
	 * Metoda zkontroluje skutecnosti pro schvaleni menu a pote zavola metodu na schvaleni menu
	 */
	public void schvalMenu() throws JSONException 
	{
		if(!menu.getHotovo()) 
		{
			Alert alert = new Alert(AlertType.WARNING, "Opravdu chcete menu schválit?", ButtonType.YES, ButtonType.NO);
			alert.setTitle("Schválení menu");
			alert.setHeaderText("Schválit menu na den " + menu.getDatum() + "? Tato akce odbaví suroviny potřebné k menu ze skladu.");
			alert.showAndWait();
			
			if(alert.getResult() == ButtonType.YES) 
			{
				for(int i=0; i < menuSuroviny.getItems().size(); i++) 
				{
					for(int j=0; j < sklad.size(); j++)
					{
						if(menuSuroviny.getItems().get(i).getNazev().equals(sklad.get(j).getNazev())) 
						{
							fileManager.writeSklad(sklad.get(j).getNazev(), menuSuroviny.getItems().get(i).getMnozstvi(), sklad.get(j).getJednotka(), true);
							break;
						}
					}
				}
				
				menu.setHotovo(true);
				fileManager.writeMenu();
			}
		}
		updateNodes();
	}
	
	/**
	 * Metoda pro export menu do PDF.
	 */
	public void createPdf() throws FileNotFoundException, DocumentException 
	{
		List<Recept> recepty = new ArrayList<>(receptList);
		fileManager.createPdf(menu.getDatum(), recepty);
	}
}