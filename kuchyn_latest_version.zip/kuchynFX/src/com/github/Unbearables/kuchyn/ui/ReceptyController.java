package com.github.Unbearables.kuchyn.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.function.Predicate;

import org.json.JSONException;

import application.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Recept;

import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * Tento Controller ovl�d� .fxml 
 * Zobraz� dostupn� recepty..
 */

public class ReceptyController
{
	@FXML private AnchorPane recPane;
	@FXML private TableView<Recept> receptyTable;
	@FXML private TableColumn<Recept, String> nazevReceptu;
    @FXML private TableColumn<Recept, String> chodReceptu;
    @FXML private TableColumn<Recept, String> cenaReceptu;
    @FXML private TableColumn<Recept, String> trvaniReceptu;
    @FXML private TextField searchField;
    @FXML private ContextMenu tableContextMenu;
	
	private FileManager fileManager = Start.fileManager;
	private FilteredList<Recept> filterRecepty;
	
	/**
	 * JavaFX zakladni metoda, vola se na inicializovani Scene.
	 */
	public void initialize() throws FileNotFoundException, JSONException
	{
		nazevReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("nazev"));
		chodReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("chod"));
		cenaReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("cena"));
		trvaniReceptu.setCellValueFactory(new PropertyValueFactory<Recept, String>("doba"));
		
		receptyTable.setItems(fileManager.getJSONToObsList());
		if(fileManager.getRecepty() != null) 
		{
			filterRecepty = new FilteredList<Recept> (fileManager.getRecepty(), e->true);
		}
	}
	
	/**
     * Vrac� zp�t do hlavn�ho okna (zm�n� sc�nu).
     */
	public void backToTheKitchen() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (recPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	/**
     * Otev�e okno pro vytv��en� nov�ch recept� (zm�n� sc�nu).
     */
	public void goToCreateRecept() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_NewRecept.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (recPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
	/**
     * Slou�� pro pomocn� vyhled�v�n� recept�.
     */
	@SuppressWarnings("unchecked")
	public void search(KeyEvent event) 
	{
		if(fileManager.getRecepty() != null) 
		{
			searchField.textProperty().addListener((observable, oldValue, newValue) -> {
				
				filterRecepty.setPredicate((Predicate<? super Recept>) (Recept recept)->{
					
					if(newValue.isEmpty() || newValue == null) 
					{
						return true;
					}
					else if(recept.getNazev().toLowerCase().contains(newValue.toLowerCase()))
					{
						return true;
					}
					
					return false;
				});
			});
			
			@SuppressWarnings("rawtypes")
			SortedList sort = new SortedList(filterRecepty);
			sort.comparatorProperty().bind(receptyTable.comparatorProperty());
			receptyTable.setItems(sort);
		}
	}
	
	 /**
     * Pokud se mezi recepty nach�z� n�jak� polo�ka, m��e
     * tato metoda tuto polo�ku odstranit.
     */
	public void odstranRecept() throws JSONException, FileNotFoundException 
	{	
		Recept recept = receptyTable.getSelectionModel().getSelectedItem();
		
		if(recept != null) 
		{
			//popup
			Alert alert = new Alert(AlertType.WARNING, "Opravdu chcete recept odstranit? Tato akce m��e m�t dopad na vytvo�en� menu!", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
			alert.setTitle("Odstran�n� receptu");
			alert.setHeaderText("Odstranit recept: " + recept.getNazev());
			alert.showAndWait();
			
			if (alert.getResult() == ButtonType.YES) 
			{
				fileManager.odstranReceptJSON(recept);
				receptyTable.getItems().remove(recept);
				receptyTable.getSelectionModel().clearSelection();
			}
		}
	}
	
	/**
     * Pokud se mezi recepty nach�z� n�jak� polo�ka, je mo�n�
     * se pomoc� t�to metody dostat do detailu t�to polo�ky (zm�n� sc�nu).
     */
	public void goToRecept() throws IOException
	{
		Recept receptToGo = receptyTable.getSelectionModel().getSelectedItem();
		
		if(receptToGo != null) 
		{
			fileManager.setClickedRecept(receptToGo);
			
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_ReceptDetail.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (recPane.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
	}
}