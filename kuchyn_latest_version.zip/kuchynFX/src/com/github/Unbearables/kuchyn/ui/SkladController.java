package com.github.Unbearables.kuchyn.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.function.Predicate;

import org.json.JSONException;

import application.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Sklad;

import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * Tento Controller ovl�d� .fxml 
 * Zobraz� typ, mno�stv� a jednotku surovin, kter� jsou obsa�eny na sklad�.
 */

public class SkladController {

	@FXML private AnchorPane skladPane;
	@FXML private TableView<Sklad> skladTable;
	@FXML private TableColumn<Sklad, String> nazevSuroviny;
    @FXML private TableColumn<Sklad, String> mnozstviSuroviny;
    @FXML private TableColumn<Sklad, String> jednotkaSuroviny;
    @FXML private TextField hledejField;
    @FXML private ContextMenu tableContext;
	
    private FileManager fileManager = Start.fileManager;
    private FilteredList<Sklad> filterSklad;
    
    /**
	 * JavaFX zakladni metoda, vola se na inicializovani Scene.
	 */
    public void initialize() throws FileNotFoundException, JSONException
	{
		nazevSuroviny.setCellValueFactory(new PropertyValueFactory<Sklad, String>("nazev"));
		mnozstviSuroviny.setCellValueFactory(new PropertyValueFactory<Sklad, String>("mnozstvi"));
		jednotkaSuroviny.setCellValueFactory(new PropertyValueFactory<Sklad, String>("jednotka"));
		skladTable.setItems(fileManager.getJSONToSklad());
		
		skladTable.getSelectionModel().clearSelection();
		hledejField.requestFocus();
		
		if(fileManager.getSklad() != null) 
		{
			filterSklad = new FilteredList<Sklad> (fileManager.getSklad(), e->true);
			//skladTable.setItems(fileManager.getJSONToSklad());
		}
	}
    
    /**
     * Vrac� zp�t do hlavn�ho okna (zm�n� sc�nu).
     */
    public void zpet() throws IOException
    {
	    Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
    }
    
    /**
     * Slou�� pro pomocn� vyhled�v�n� surovin ve skladu.
     */
    @SuppressWarnings("unchecked")
	public void search(KeyEvent event) 
	{
		if(fileManager.getSklad() != null) 
		{
			hledejField.textProperty().addListener((observable, oldValue, newValue) -> {
				
				filterSklad.setPredicate((Predicate<? super Sklad>) (Sklad sklad)->{
					
					if(newValue.isEmpty() || newValue == null) 
					{
						return true;
					}
					else if(sklad.getNazev().toLowerCase().contains(newValue.toLowerCase()))
					{
						return true;
					}
					
					return false;
				});
			});
			
			@SuppressWarnings("rawtypes")
			SortedList sort = new SortedList(filterSklad);
			sort.comparatorProperty().bind(skladTable.comparatorProperty());
			skladTable.setItems(sort);
		}
	}
    
    /**
     * Otev�e okno pro p�id�n� nov�ho n�kupu (zm�n� sc�nu).
     */
    public void pridejNakup() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_NewSklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
    /**
     * Pokud se v seznamu se surovinami ve skladu nach�z� n�jak� polo�ka, m��e
     * tato metoda tuto polo�ku odstranit.
     */
    public void odstranSkladovouSurovinu() throws JSONException, FileNotFoundException 
	{	
		Sklad sklad = skladTable.getSelectionModel().getSelectedItem();
		
		if(sklad != null) 
		{
			//popup
			Alert alert = new Alert(AlertType.WARNING, "Opravdu chcete z�sobu odstranit?", ButtonType.YES, ButtonType.NO, ButtonType.CANCEL);
			alert.setTitle("Odstran�n� z�soby");
			alert.setHeaderText("Odstranit surovinu: " + sklad.getNazev());
			alert.showAndWait();
			
			if (alert.getResult() == ButtonType.YES) 
			{
				fileManager.odstranSkladJSON(sklad);
				skladTable.getItems().remove(sklad);
				skladTable.getSelectionModel().clearSelection();
			}
		}
	}
    
    /**
     * Pokud se v seznamu se surovinami ve skladu nach�z� n�jak� polo�ka, je mo�n�
     * se pomoc� t�to metody dostat do detailu t�to polo�ky (zm�n� sc�nu).
     */
    public void jdiSkladoveSuroviny() throws IOException
	{
		Sklad jdiSkladove = skladTable.getSelectionModel().getSelectedItem();
		
		if(jdiSkladove != null) 
		{
			fileManager.setClickedSklad(jdiSkladove);
			
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_SkladDetail.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (skladPane.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
	}
}
