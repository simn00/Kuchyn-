package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;

import org.json.JSONException;

import application.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Sklad;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SkladDetailController
{
	@FXML private AnchorPane detailSkladPane;
	@FXML private Label nazev;
	@FXML private Label mnozstvi;
	@FXML private Label jednotka;
	@FXML private Label errorMnozstvi;
	@FXML private TextField odecetMnozstvi;
	
	private FileManager fileManager = Start.fileManager;
	private Sklad sklad;
	
	public void initialize() 
	{
		sklad = fileManager.getClickedSklad();
		nazev.setText(sklad.getNazev());
		mnozstvi.setText(sklad.getMnozstvi() + "");
		jednotka.setText(sklad.getJednotka());
	
		errorMnozstvi.setText(null);
		odecetMnozstvi.setText(null);
	}
	
	public void zmenaMnozstvi() throws IOException, JSONException
	{
		if(odecetMnozstvi.getText() != null)
		{
			if(odecetMnozstvi.getText().matches("(0\\.\\d*[1-9]\\d*|[1-9]\\d*(\\.\\d+)?)$"))
			{
				float konecna = Float.parseFloat(mnozstvi.getText()) - Float.parseFloat(odecetMnozstvi.getText());
				
				if(konecna >= 0)
				{
					fileManager.writeSklad(nazev.getText(), Float.parseFloat(odecetMnozstvi.getText()), jednotka.getText(), true);
					//sklad.deleteMnozstvi(Float.parseFloat(odecetMnozstvi.getText()));
					mnozstvi.setText(sklad.getMnozstvi() + "");
					odecetMnozstvi.setText("");
				}
				else
				{
					errorMnozstvi.setText("Tolik suroviny není na skladu.");
					odecetMnozstvi.setText(null);
				}	
			}
			else 
			{
				errorMnozstvi.setText(odecetMnozstvi.getText() + " není správné množství!");
				odecetMnozstvi.setText(null);
			}
		}
		else
		{		
			errorMnozstvi.setText("Musíš zadat číslo k odečtení.");		
		}
	}
	
	public void zpetNaSklad() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (detailSkladPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
}