package application;
	
import com.github.Unbearables.kuchyn.process.FileManager;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Start extends Application
{
	public static FileManager fileManager = new FileManager();
	
	public static void main(String[] args)
    {    	
		System.out.println("launching app");
		launch(args);        
    }
    
    /**
	 * Metoda, ve kter� se konstruuje okno, kontroler a hra,
	 * kter� se p�ed�v� kontroleru
	 */
	@Override
	public void start(Stage primaryStage) throws Exception 
	{
		fileManager.initialize();
		
		if(fileManager.getFirstStart()) 
		{
			FXMLLoader loader = new FXMLLoader();
	    	loader.setLocation(getClass().getResource("/Kuchyn_FirstStart.fxml"));    	
	    	Parent root = loader.load();
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
			primaryStage.setTitle("Kuchyne");
		}
		else 
		{			
			FXMLLoader loader = new FXMLLoader();
	    	loader.setLocation(getClass().getResource("/Kuchyn_MainWindow.fxml"));
	    	Parent root = loader.load();
			primaryStage.setScene(new Scene(root));
			primaryStage.show();
			primaryStage.setTitle("Kuchyne");
		}
	}	
}
