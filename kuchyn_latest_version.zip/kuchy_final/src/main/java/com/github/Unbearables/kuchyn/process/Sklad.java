package com.github.Unbearables.kuchyn.process;

public class Sklad {

	private String nazev;
	private float mnozstvi;
	
	public Sklad(String nazev, float mnozstvi)
	{
		this.nazev = nazev;
		this.mnozstvi = mnozstvi;
	}
	
	public String getNazev() 
	{
		return nazev;
	}
	
	public float getMnozstvi() 
	{
		return mnozstvi;
	}
	
	public String toString() 
	{
		return nazev;
	}
	
	public void setMnozstvi(float mnoz)
	{
		this.mnozstvi = mnoz;
	}

	public void addMnozstvi(float mnozToAdd) 
	{
		mnozstvi += mnozToAdd;
	}
	
	public void deleteMnozstvi(float mnozToDelete) 
	{
		mnozstvi -= mnozToDelete;
	}	
	
}
