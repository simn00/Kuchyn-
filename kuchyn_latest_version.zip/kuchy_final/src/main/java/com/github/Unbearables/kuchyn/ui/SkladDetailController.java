package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;

import org.json.JSONException;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Sklad;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SkladDetailController
{
	@FXML private AnchorPane skladDetailPane;
	@FXML private Label nazev;
	@FXML private TextField mnozstvi;
	@FXML private Label errorMnozstvi;
	
	private FileManager fileManager = Start.fileManager;
	
	private Sklad sklad;
	
	
	public void initialize() 
	{
		sklad = fileManager.getClickedSklad();
		nazev.setText(sklad.getNazev());
		mnozstvi.setText(sklad.getMnozstvi() + "");
		
		errorMnozstvi.setText(null);
	}
	
	public void takeData() 
	{
		
	}
	
	public void zmenaMnozstvi() throws IOException, JSONException
	{
		if(mnozstvi.getText() != null && mnozstvi.getText().matches("^-?(0\\.\\d*[1-9]\\d*|[1-9]\\d*(\\.\\d+)?)$")) 
		{
			fileManager.writeUpravaSkladu(nazev.getText(), Float.parseFloat(mnozstvi.getText()));
			zpetNaSklad();
		}
		else 
		{
			errorMnozstvi.setText(mnozstvi.getText() + " není správné množství!");
		}
	}
	
	public void zpetNaSklad() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladDetailPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
}