package com.github.Unbearables.kuchyn.ui;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.function.Predicate;

import org.json.JSONException;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Recept;
import com.github.Unbearables.kuchyn.process.Sklad;
import com.github.Unbearables.kuchyn.process.Surovina;

import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class SkladController {

	@FXML private AnchorPane skladPane;
	@FXML private TableView<Sklad> skladTable;
	@FXML private TableColumn<Sklad, String> nazevSuroviny;
    @FXML private TableColumn<Sklad, String> mnozstviSuroviny;
    @FXML private TextField hledejField;
    @FXML private ContextMenu tableContext;
	
    private FileManager fileManager = Start.fileManager;
    private FilteredList<Sklad> filterSklad;
    
    public void initialize() throws FileNotFoundException, JSONException
	{
		nazevSuroviny.setCellValueFactory(new PropertyValueFactory<Sklad, String>("nazev"));
		mnozstviSuroviny.setCellValueFactory(new PropertyValueFactory<Sklad, String>("mnozstvi"));
		skladTable.setItems(fileManager.getJSONToSklad());
		
		skladTable.getSelectionModel().clearSelection();
		hledejField.requestFocus();
		
		if(fileManager.getSklad() != null) 
		{
		filterSklad = new FilteredList<Sklad> (fileManager.getSklad(), e->true);
		//skladTable.setItems(fileManager.getJSONToSklad());
		}
	}
    
    public void zpet() throws IOException
    {
	    Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
    }
    
    @SuppressWarnings("unchecked")
	public void search(KeyEvent event) 
	{
		if(fileManager.getSklad() != null) 
		{
			hledejField.textProperty().addListener((observable, oldValue, newValue) -> {
				
				filterSklad.setPredicate((Predicate<? super Sklad>) (Sklad sklad)->{
					
					if(newValue.isEmpty() || newValue == null) 
					{
						return true;
					}
					else if(sklad.getNazev().toLowerCase().contains(newValue.toLowerCase()))
					{
						return true;
					}
					
					return false;
				});
			});
			
			@SuppressWarnings("rawtypes")
			SortedList sort = new SortedList(filterSklad);
			sort.comparatorProperty().bind(skladTable.comparatorProperty());
			skladTable.setItems(sort);
		}
	}
    
    public void pridejSkladovouSurovinu() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_NewSklad.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (skladPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}	
	
    public void odstranSkladovouSurovinu() throws JSONException, FileNotFoundException 
	{	
		Sklad sklad = skladTable.getSelectionModel().getSelectedItem();
		
		if(sklad != null) 
		{
			fileManager.odstranSkladJSON(sklad);
			skladTable.getItems().remove(sklad);
			skladTable.getSelectionModel().clearSelection();
		}
	}
    
    public void jdiSkladoveSuroviny() throws IOException
	{
		Sklad jdiSkladove = skladTable.getSelectionModel().getSelectedItem();
		
		if(jdiSkladove != null) 
		{
			fileManager.setClickedSklad(jdiSkladove);
			
			Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_SkladDetail.fxml"));
			Scene menu_overview_scene = new Scene(menu_overview_parent);
			Stage app_stage = (Stage) (skladPane.getScene().getWindow());
			app_stage.setScene(menu_overview_scene);
			app_stage.show();
		}
	}
}
