package com.github.Unbearables.kuchyn.process;

import java.util.List;

public class Menu 
{
	private String datum;
	private List<String> recepty;
	private boolean hotovo;
	
	public Menu(String datum, List<String> recepty) 
	{
		this.datum = datum;
		this.recepty = recepty;
		this.hotovo = false;
	}
	
	public String getDatum() 
	{
		return datum;
	}
	
	public List<String> getRecepty() 
	{
		return recepty;
	}
	
	public boolean getHotovo() 
	{
		return hotovo;
	}
	
	public void setHotovo(boolean bool) 
	{
		hotovo = bool;
	}
}
