package com.github.Unbearables.kuchyn.process;

public class Sklad {

	private String nazev;
	private float mnozstvi;
	private String jednotka;
	
	public Sklad(String nazev, float mnozstvi, String jednotka)
	{
		this.nazev = nazev;
		this.mnozstvi = mnozstvi;
		this.jednotka = jednotka;
	}
	
	public String getNazev() 
	{
		return nazev;
	}
	
	public float getMnozstvi() 
	{
		return mnozstvi;
	}
	
	public String getJednotka() 
	{
		return jednotka;
	}
	
	public String toString() 
	{
		return nazev;
	}
	
	public void setMnozstvi(float mnoz)
	{
		this.mnozstvi = mnoz;
	}

	public void addMnozstvi(float mnozToAdd) 
	{
		mnozstvi += mnozToAdd;
	}
	
	public void deleteMnozstvi(float mnozToDelete) 
	{
		mnozstvi -= mnozToDelete;
	}	
	
}
