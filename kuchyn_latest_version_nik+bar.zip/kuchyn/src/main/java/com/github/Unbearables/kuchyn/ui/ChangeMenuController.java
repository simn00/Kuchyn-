package com.github.Unbearables.kuchyn.ui;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.process.Menu;
import com.github.Unbearables.kuchyn.process.Recept;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class ChangeMenuController
{
	@FXML AnchorPane changeMenuPane;
	@FXML DatePicker datumMenu;
	@FXML Slider pocetReceptu;
	@FXML Label error;
	
	@FXML HBox boxRecept1;
	@FXML HBox boxRecept2;
	@FXML HBox boxRecept3;
	@FXML HBox boxRecept4;
	@FXML HBox boxRecept5;
	
	@FXML TextField nazRec1;
	@FXML TextField nazRec2;
	@FXML TextField nazRec3;
	@FXML TextField nazRec4;
	@FXML TextField nazRec5;

	@FXML TextField pocRec1;
	@FXML TextField pocRec2;
	@FXML TextField pocRec3;
	@FXML TextField pocRec4;
	@FXML TextField pocRec5;
	
	@FXML Label cis1;
	@FXML Label cis2;
	@FXML Label cis3;
	@FXML Label cis4;
	@FXML Label cis5;
	
	private FileManager fileManager = Start.fileManager;
	private List<Menu> menuList;
	private List<String> menuRecepty;
	private List<String> receptyList;
	
	private DateTimeFormatter dtf;
	
	private Menu menu;
	private JSONArray receptyArr;
	
	private ObservableList<Recept> recepty;
	private Menu menuPuvodni;
	private String thisMenuDate;
	
	public void initialize() 
	{
		dtf = DateTimeFormatter.ofPattern("dd.MM.yyyy");
		thisMenuDate = fileManager.getClickedMenuDatum();
		LocalDate theDay = LocalDate.parse(thisMenuDate, dtf);
		datumMenu.setValue(theDay);
		
		menuList = fileManager.getMenues();
		System.out.println(menuList);
		
		for( int i=0 ; i < menuList.size() ; i++ ) 
		{
			if(menuList.get(i).getDatum().equals(fileManager.getClickedMenuDatum())) 
			{
				menuPuvodni = menuList.get(i);
			}
		}
		
		//set stuff
		menuRecepty = new ArrayList<String>();
		menuRecepty = menuPuvodni.getRecepty();
		
		receptyList = new ArrayList<String>();
		recepty = fileManager.getRecepty();
		System.out.println(recepty);
		afetInit();
	}
	
	//.lookup() doesnt work in initialize due to objects not being rendered in the scene, kill me
	public void afetInit() 
	{
		boxRecept1.setDisable(true);
		boxRecept2.setDisable(true);
		boxRecept3.setDisable(true);
		boxRecept4.setDisable(true);
		boxRecept5.setDisable(true);
		cis1.setVisible(false);
		cis2.setVisible(false);
		cis3.setVisible(false);
		cis4.setVisible(false);
		cis5.setVisible(false);
		
		for( int i=0 ; i < menuRecepty.size() ; i++ ) 
		{
			String[] kek = menuRecepty.get(i).split("_");
			//hardcoding, no other way
			if(i == 0) 
			{
				boxRecept1.setDisable(false);
				nazRec1.setText(kek[0]);
				pocRec1.setText(kek[1]);
				cis1.setVisible(true);
			}
			else if(i == 1) 
			{
				boxRecept2.setDisable(false);
				nazRec2.setText(kek[0]);
				pocRec2.setText(kek[1]);
				cis2.setVisible(true);
			}
			else if(i == 2) 
			{
				boxRecept3.setDisable(false);
				nazRec3.setText(kek[0]);
				pocRec3.setText(kek[1]);
				cis3.setVisible(true);
			}
			else if(i == 3) 
			{
				boxRecept4.setDisable(false);
				nazRec4.setText(kek[0]);
				pocRec4.setText(kek[1]);
				cis4.setVisible(true);
			}
			else 
			{
				boxRecept5.setDisable(false);
				nazRec5.setText(kek[0]);
				pocRec5.setText(kek[1]);
				cis5.setVisible(true);
			}
		}
		
		pocetReceptu.setValue(menuRecepty.size());
	}
	
	public void backToMenu() throws IOException 
	{
		Parent menu_overview_parent = FXMLLoader.load(getClass().getResource("/Kuchyn_Menu.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (changeMenuPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void updatePocetReceptu() 
	{
		boxRecept1.setDisable(true);
		boxRecept2.setDisable(true);
		boxRecept3.setDisable(true);
		boxRecept4.setDisable(true);
		boxRecept5.setDisable(true);
		cis1.setVisible(false);
		cis2.setVisible(false);
		cis3.setVisible(false);
		cis4.setVisible(false);
		cis5.setVisible(false);
		
		for( int i=1 ; i <= pocetReceptu.getValue() ; i++) 
		{
			HBox box = (HBox) changeMenuPane.getScene().lookup("#boxRecept" + i);
			Label cislo = (Label) changeMenuPane.getScene().lookup("#cis" + i);
			
			if(box.isDisabled()) 
			{
				box.setDisable(false);
				cislo.setVisible(true);
			}
		}
	}
	
	public void createMenu() throws IOException, JSONException 
	{
		if(datumMenu.getValue() != null) 
		{
			validate();
			
			if(validate()) 
			{
				checkForDuplicate();
			}
			
			boolean bro = false;
			TextField focusOn = null;
			receptyArr = new JSONArray();
			
			if(validate() && !checkForDuplicate()) 
			{
				for(int i=1 ; i < (pocetReceptu.getValue() + 1); i++) 
				{
					focusOn = null;
					focusOn = (TextField) changeMenuPane.getScene().lookup("#nazRec" + i);
					focusOn.setStyle(null);
					error.setText("");
					
					for(int j=0 ; j < recepty.size() ; j++) 
					{
						bro = false;
						
						if(recepty.get(j).getNazev().equals(focusOn.getText())) 
						{
							TextField tf2 = (TextField) changeMenuPane.getScene().lookup("#pocRec" + i);
							String rec = focusOn.getText() + "_" + tf2.getText();
							receptyArr.put(rec);
							receptyList.add(rec);
							bro = true;
							break;
						}
					}
					
					if(!bro) 
					{
						error.setText("Recept " + i + " neexistuje.");
						break;
					}
				}
				
				if(bro) 
				{
					menu = new Menu(datumMenu.getValue().format(dtf).toString(), receptyList);
					System.out.println(menu.getDatum() + " & " + menu.getRecepty());
					//uprava
					fileManager.upravaMenu(menu);
					backToMenu();
				}
				else 
				{
					focusOn.setStyle("-fx-text-box-border: red ; -fx-focus-color: red ;");
				}
			}
			else 
			{
				System.out.println("couldnt finish MENU");
			}
		}
		else 
		{
			error.setText("Datum pro menu není určeno.");
		}
	}
	
	//true != OK
	public boolean checkForDuplicate() 
	{
		for(int i=0 ; i < menuList.size() ; i++)
		{
			if(menuList.get(i).getDatum().equals(datumMenu.getValue().format(dtf))) 
			{	
				if(!menuList.get(i).getDatum().equals(thisMenuDate)) 
				{
					error.setText("Menu na den " + datumMenu.getValue().format(dtf) + " již existuje!");
					return true;
				}
			}
		}
		
		return false;
	}
	
	//true = OK
	public boolean validate() 
	{
		for(int i=1 ; i < (pocetReceptu.getValue() + 1); i++) 
		{
			TextField tf1 = (TextField) changeMenuPane.getScene().lookup("#nazRec" + i);
			TextField tf2 = (TextField) changeMenuPane.getScene().lookup("#pocRec" + i);
			
			if(tf1.getText() != null && !tf2.getText().matches("^[1-9]\\d*")) 
			{
				error.setText("Recept " + i + " je špatně zadán!");
				return false;
			}
		}
				
		return true;
	}
}