package com.github.Unbearables.kuchyn.ui;

import com.github.Unbearables.kuchyn.process.FileManager;
import com.github.Unbearables.kuchyn.main.Start;

import java.io.IOException;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class FirstStartController
{
	@FXML private AnchorPane rootPane3;
	@FXML private TextField name;
	@FXML private TextField type;
	@FXML private TextField ico;
	@FXML private Label error;
	@FXML private Label welcome;
	@FXML private Button zpetBtn;
	
	private FileManager fileManager = Start.fileManager;
	private boolean firstStart;
	
	public void initialize()
	{
		firstStart = fileManager.getFirstStart();
		
		
		if(fileManager.getFirstStart()) 
		{
			zpetBtn.setVisible(false);
		}
		else
		{
			welcome.setText("Změnit informace:");
			name.setText(fileManager.getKitchenName());
			type.setText(fileManager.getKitchenType());
			ico.setText(fileManager.getKitchenIco());
		}
	}

	public void createAndContinue() throws IOException
	{
		if(name.getText() != null && type.getText() != null && ico.getText() != null) 
		{
			if(name.getLength() < 50) 
			{
				if(type.getText().matches("[ěščřžýáíéóúůďťňĎŇŤŠČŘŽÝÁÍÉÚŮa-zA-z]{1,20}")) 
				{
					if(ico.getText().matches("\\d{8}")) 
					{
						if(overIco(ico.getText())) 
						{
							if(firstStart) 
							{
								fileManager.createMainTxt(name.getText(), type.getText(), ico.getText());
								fileManager.setFirstStart(false);
								toMainWindow();
							}
							else 
							{
								Alert alert = new Alert(AlertType.WARNING,
										"Opravdu chcete změnit tyto informace:\nNázev:\n" +
										fileManager.getKitchenName() + " -> " + name.getText() +
										"\nTyp kuchyně:\n" +
										fileManager.getKitchenType() + " -> " + type.getText() +
										"\nIČO:\n" +
										fileManager.getKitchenIco() + " -> " + ico.getText()
										, ButtonType.YES, ButtonType.NO);
								alert.setTitle("Změnit informace");
								alert.setHeaderText("Změnit informace o kuchyni?");
								alert.showAndWait();
								
								if (alert.getResult() == ButtonType.YES) 
								{
									fileManager.createMainTxt(name.getText(), type.getText(), ico.getText());
									toMainWindow();
								}
							}
						}
						else
						{
							error.setText("IČO není validní!");
						}
					}
					else
					{
						error.setText("IČO je osmimístné a obsahuje jen čísla!");
					}
				}
				else
				{
					error.setText("Typ restaurce nelze zapsat!");
				}
			}	
			else
			{
				error.setText("Jméno restaurace je příliš dlouhé!");
			}
		}
		else
		{
			error.setText("Musíš vyplnit všechny údaje!");
		}
	}	
	
	public boolean overIco(String ico) 
	{
		char[] split = ico.toCharArray();
		int soucet = 0;
		int vaha = 8;
		
		for(int i=0; i < split.length - 1; i++) 
		{
			int cis = Character.getNumericValue(split[i]) * vaha;
			vaha--;
			soucet += cis;
		}
		
		if((11 - (soucet % 11)) % 10 == Character.getNumericValue(split[7])) 
		{
			System.out.println(ico + " je ok");
			return true;
		}
		return false;
	}
	
	public void toMainWindow() throws IOException 
	{		
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/Kuchyn_MainWindow.fxml"));
		Parent root = (Parent) loader.load();
		Scene menu_overview_scene = new Scene(root);
		Stage app_stage = (Stage) (rootPane3.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();		
	}	
}