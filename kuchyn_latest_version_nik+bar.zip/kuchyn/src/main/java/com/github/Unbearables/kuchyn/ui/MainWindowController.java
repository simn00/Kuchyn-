package com.github.Unbearables.kuchyn.ui;

import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.github.Unbearables.kuchyn.main.Start;
import com.github.Unbearables.kuchyn.process.FileManager;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

public class MainWindowController extends AnchorPane
{
	@FXML private AnchorPane rootPane;
	@FXML private Label testLabel;
	@FXML private Label kitchenName;
	@FXML private Label kitchenType;
	
	private FileManager fileManager = Start.fileManager;
	private FXMLLoader loader;

	public void initialize() 
	{
		kitchenName.setText(fileManager.getKitchenName());
		kitchenType.setText(fileManager.getKitchenType());
		loader = new FXMLLoader();
	}
	
	public void otevriMenuOverview() throws IOException 
	{
		
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_Menu.fxml"));
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void otevriReceptyOverview() throws IOException
	{
		//FXMLLoader loader = new FXMLLoader();
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_Recepty.fxml"));		
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void otevriSkladOverview() throws IOException
	{
		//FXMLLoader loader = new FXMLLoader();
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_Sklad.fxml"));		
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void otevriKuchynInfo() throws IOException
	{
		Parent menu_overview_parent = loader.load(getClass().getResource("/Kuchyn_FirstStart.fxml"));		
		Scene menu_overview_scene = new Scene(menu_overview_parent);
		Stage app_stage = (Stage) (rootPane.getScene().getWindow());
		app_stage.setScene(menu_overview_scene);
		app_stage.show();
	}
	
	public void test() throws JSONException 
	{
		JSONObject obj = new JSONObject();
		
		obj.put("nazev","Palačinky");
		obj.put("chod","dezert");
		
		JSONArray listSur = new JSONArray();
		JSONObject obj1 = new JSONObject();
		JSONObject obj2 = new JSONObject();
		JSONObject obj3 = new JSONObject();
		
		obj1.put("vejce",3);
		obj2.put("mouka",100);
		obj3.put("mléko",50);
		
		listSur.put(obj1);
		listSur.put(obj2);
		listSur.put(obj3);
		
		obj.put("suroviny",listSur);
		
		try (PrintWriter writer = new PrintWriter(new FileOutputStream(fileManager.getFile(),true)))
		{
			//empty json file starts with 3chars
			if(fileManager.getFile().length() == 3)
			{
				writer.write(obj.toString());
			}
			else 
			{
				writer.write("," + obj.toString());
			}
				System.out.println(fileManager.getFile().length());
		} 
		catch(IOException e) {}
	}
	
	public void testDva() throws JSONException 
	{
		JSONObject obj = new JSONObject();
		
		obj.put("test1","test2");
		
		System.out.println(obj);
		
		try (FileWriter file = new FileWriter(fileManager.getFile()))
		{
			file.write(obj.toString());
		} 
		catch(IOException e) {}
	}
}